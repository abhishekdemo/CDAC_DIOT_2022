/*----------------------------------------------
 * Description: A program to open a serial port and receive the data. 
   JSON data format is expected
 * ---------------------------------------*/
const serialport = require('serialport');
const events = require("events");

const esp = new events();

// Define the port path and baudrate here
const portESP = new serialport.SerialPort({
    path: "/dev/pts/2",
    baudRate: 9600
})

// When Port get opened.
portESP.on('open',()=>{
    console.log("Port opened!")
})

// Handle the data on Port; JSON parser used
portESP.on('data',(data) => {
    try{
        data = JSON.parse(data.toString())
        esp.emit("sensorValue",null,data);
    } catch(error){
        esp.emit("sensorValue",{message: "JSON parsing error"},null)
    }
})

// Send the data on serial port; String as parameter
const sendData = (data)=>{
    portESP.write(Buffer.from(data))
}

module.exports = {
    esp
}