// Program to publish data to Broker on TOPIC
const mqtt = require('mqtt');
//const WILL_TOPIC='/cdac/device/dead';

const HOST = 'mqtt://localhost:';
const PORT = '1880';

const subscriber = mqtt.connect(HOST + PORT , {
    clean: false,
    clientId: "diot0002",
    will:{
        topic:'/cdac/device/dead',payload:'diot0001',qos:1,retain:true
    }
});

// MQTT Topic to Publish data to
const TOPIC = 'cdac/#';
const WILL_TOPIC='/cdac/device/diot';
const SYSTEM_TOPIC='$SYS'

// Event to Check BROKER connection
subscriber.on('connect',()=>{
    
    console.log("Connected to MQTT Broker!");

    // subscribe the TOPIC
    subscriber.subscribe(TOPIC,{qos:2}, (err, granted)=>{
        if(!err){
            console.log(`Granted! Topic: ${granted[0].topic}, QoS: ${granted[0].qos}`);
        }
    });
})

// Print Published Messages 
subscriber.on('message',(topic,data)=>{
    console.log(`Topic: ${topic}, Message: ${data.toString()}`);
})


