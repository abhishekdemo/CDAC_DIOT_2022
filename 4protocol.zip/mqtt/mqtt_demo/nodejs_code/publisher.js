// Program to publish data to Broker on TOPIC
const mqtt = require('mqtt');

const HOST = 'mqtt://localhost:';
const PORT = '1880';

const publisher = mqtt.connect(HOST + PORT, {
    clean: false,
    clientId: "diot0001",will:{
        topic:'/cdac/device/dead',payload:'diot0001',qos:1,retain:true
    }
    
});

// MQTT Topic to Publish data to
const TOPIC = 'cdac/sensor/temp';

// Event to Check BROKER connection
publisher.on('connect',()=>{
    
    console.log("Connected to MQTT Broker!");

    let counter = 0;
    const loop = setInterval(()=>{
        counter++;
        // Publish the data
        publisher.publish(TOPIC,'{"sensor":24.5}',{
            qos: 2
        },(err)=>{
            if(!err) {
                console.log("Message published: "+counter);
            }
        })
        if(counter==5){
            clearInterval(loop);
            //publisher.end();
            // closing connectioon  rudly

            process.exit()
        }
    },1000);
})


