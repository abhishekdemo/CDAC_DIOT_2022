module.export={
    mqtt:
    {
        authenicate:function(client,username,password,callback)
        {
            let authenicate= false;

            if(username==='admin' && password.toString()=='admin')
            {
                if(client.user=== username)
                {
                    authenicate=true;
                }
            }

            callback(null,authenicate);
        },

        authorizePublish:function(client,topic,payload,callback)
        {
            callback(null,true);

        },
        authorizeSubscribe:function(client,topic,callback){

            callback(null,true);
    }

}
}
