#include"primeno.h"
#include<stdio.h>

int main()

{
  int res,iNum1=100,iNum2=20,iNum3=3;
  res = Addition(iNum1, iNum2, iNum3);
  printf("Addition : %d\n",res);


   res=Substraction(iNum1,iNum3);
  printf("Substraction :%d\n",res);

 res=Multiplication(iNum2,iNum3);
  printf("Multiplication : %d\n",res);


 res=Division(iNum1,iNum2);
  printf("Division : %d\n",res);

  return 0;


}

