

// fun Decla


//Add Fun

int Addition(int iNum1, int iNum2, int iNum3);

//Sub Fun


int Substraction(int iNum1, int iNum2);

//Mul Fun

int Multiplication(int iNum1, int iNum2);

//Div Fun

int Division(int iNum1, int iNum2);
