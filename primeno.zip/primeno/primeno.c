#include"primeno.h"
#include<stdio.h>

//Add Fun

int Addition(int iNum1, int iNum2, int iNum3)
{

  return iNum1+iNum2+iNum3;

}

//Sub Fun


int Substraction(int iNum1, int iNum2)
{

  return iNum1-iNum2;

}

//Mul Fun

int Multiplication(int iNum1, int iNum2)
{

 return iNum1*iNum2;

}

//Div Fun

int Division(int iNum1, int iNum2)

{

  return iNum1/iNum2;

}


