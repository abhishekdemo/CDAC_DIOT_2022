package com.cdac;

public class JavaCar extends acceleratable implements Brakeable,Coolable{
	
	public void brake() {
		System.out.println("Stopping the car!!!!");
	}
	public void switchOnAC() {
		System.out.println("Cooling the car!!!!");
		
	}

	public static void main(String[] args) {
		JavaCar car=new JavaCar();
		car.Accelerate();
		car.brake();
		car.switchOnAC();
	}
	
	
}
