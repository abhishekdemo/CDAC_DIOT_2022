package com.cdac;
import java.util.Scanner;


public class Calculator{
	
	public static void PerformDiv()
	
	{
		Scanner sc =new Scanner(System.in);
		
		//ghyt
		System.out.println("enter no 1");
		 int a=sc.nextInt();
		 
		 System.out.println("enter no 2=");
		 int b=sc.nextInt();
		 if(b==0)
		 
			 throw new InvalidInputException("You can not enter 0 as denominator");
		 
		 int c=a/b;
		 System.out.println("Div"+c);
		 
	}
	
	public static void main(String[] args) {
		PerformDiv();
	}
		 
		 
		 
	}


