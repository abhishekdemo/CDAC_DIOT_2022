package com.cdac;

public class Interface_Handling {
	public static void main(String[] args) {
		 int i=10;
		// int i=90;
		 int j=i;
		
		System.out.println(++j);
	}

}
