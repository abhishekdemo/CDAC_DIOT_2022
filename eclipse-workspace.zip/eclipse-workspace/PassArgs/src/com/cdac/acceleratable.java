package com.cdac;

public class acceleratable {
	public void Accelerate() {
		System.out.println("accelerating the car!!!!");
	}

}
