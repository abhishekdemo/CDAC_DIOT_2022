package com.cdac;
import java.util.Date;
public class ExceptionDemo {
	public static void main(String[] args) {
		
		/*String s1="null";
		int [] arr= {1,2,3,45};
		String s2;
		System.out.println( new Date().getTime());
		try {
		Thread.sleep(500);
		}
		
		catch(InterruptedException ie)
		{
			
		}*/
		
		//System.out.println(s1.length());
		/*int [] arr= {1,2,3,45};
		System.out.println("1");
		System.out.println(arr[5]);
		System.out.println("3");*/rtr
		
	}

}
