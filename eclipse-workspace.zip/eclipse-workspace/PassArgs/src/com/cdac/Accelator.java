package com.cdac;

public class Accelator {

}
