package com.cdac;

public interface Coolable {
	public void switchOnAC();

}
