package com.cdac;

public interface Brakeable {
	public void brake();

}
