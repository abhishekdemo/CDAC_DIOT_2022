/**
 * 
 */
/**
 * @author diot
 *
 */
module PassArgs {
}