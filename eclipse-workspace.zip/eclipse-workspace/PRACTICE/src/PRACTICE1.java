
public class PRACTICE1 {

}
