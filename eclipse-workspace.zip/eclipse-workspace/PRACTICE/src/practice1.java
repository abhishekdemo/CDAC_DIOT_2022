
public class practice1 {

}
