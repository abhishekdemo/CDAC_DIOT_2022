package abhi.com;

public class Syrup1 extends demo_medicine{
	public void Syrup1(String Manufacturer, double price, String ExpDate) {
		// TODO Auto-generated constructor stub
	}

	public void displayLabel() {
		System.out.println("Take directly");
	}

}
