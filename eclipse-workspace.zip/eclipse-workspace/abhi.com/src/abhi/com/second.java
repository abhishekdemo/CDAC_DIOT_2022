package abhi.com;

import java.util.Scanner;

public class second {

	
	public static void main(String[] args) {
		System.out.println("wah kya programing h");
		
		Scanner obj=new Scanner(System.in);
		String age=obj.next();
		System.out.print(age);
	}
}
