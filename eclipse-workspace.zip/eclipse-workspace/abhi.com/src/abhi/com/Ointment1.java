package abhi.com;

public class Ointment1 extends demo_medicine{
public void displayLabel() {
	System.out.println("For external use only");
}
}
