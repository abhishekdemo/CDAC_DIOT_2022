package abhi.com;

public  abstract class demo_medicine {
	
		String Manufacturer;
		double price;
		String ExpDate;
		
		
		public demo_medicine(String Manufacturer,double price,String ExpDate) {
			this.Manufacturer=Manufacturer;
			this.price=price;
			this.ExpDate=ExpDate;
			
		}

		public String getManufacturer() {
			return Manufacturer;
		}

		
		
		
		
		

		public void setManufacturer(String manufacturer) {
			Manufacturer = manufacturer;
		}

		public float getPrice() {
			return price;
		}

		public void setPrice(float price) {
			this.price = price;
		}

		public String getExpDate1() {
			return ExpDate;
		}

		public void setExpDate(String dd,String mm,String yy) {
			
			this.ExpDate = dd+"/"+mm+"/"+yy;
		}

		public abstract void displayLabel();
		
	}



