package abhi.com;

public class TestMedicine {
public static void main(String[] args) {
        
        demo_medicine t=new Tablet1("Urocare",400.0,"09-11-22");
        demo_medicine s=new Syrup1("Cough Syrup",100.4,"12-11-22");
        demo_medicine o=new Ointment1("Moov", 70.2, "10-11-22");

        demo_medicine med[]= new demo_medicine[3] ;

        med[0]=t;
        med[1]=s;
        med[2]=o;

        for( demo_medicine m:med){
            m.getDetails();
            m.displayLabel();
            System.out.println("----------------------------------------------");
            
            

        }

}
