package abhi.com;

public class first {

}
