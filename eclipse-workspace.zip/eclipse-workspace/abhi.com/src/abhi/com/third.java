package abhi.com;

public class third {
	
	public static void main(String[] args) {
		System.out.println("hey you are in  cool");
		int i=0;
		
		do
		{
			System.out.println("hello_world");
			i++;
		}
		while(i<5);
		/*while( i<5)
		{
			System.out.println("Hello_world");
			i++;
		}*/
	}

}
