package abhi.com;

public class First {
	
	   static int welcome(int a,int b)
	{
		return a+b;
	}

	public static void main(String[] args) {
		
	//	welcome(2,32);
		System.out.println(welcome(2,32));
	}
}
