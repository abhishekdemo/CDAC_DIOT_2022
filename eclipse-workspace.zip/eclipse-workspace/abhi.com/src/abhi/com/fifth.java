package abhi.com;

public class fifth {
	public static void main(String[] args) {
		//this is array programe
		
		int arr[]=new int[5];
		
		arr[0]=5;
		arr[1]=4;
		arr[2]=7;
		arr[3]=8;
		arr[4]=34;
		
		
		for(int i=0;i<arr.length;i++)
		{
			int k=0;
			k++;
			System.out.println(arr[k]+"-" +"eelment is a="+arr[i]);
		}
	}

}
