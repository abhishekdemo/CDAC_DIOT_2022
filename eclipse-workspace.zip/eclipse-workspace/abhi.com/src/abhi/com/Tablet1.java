package abhi.com;

public class Tablet1 extends demo_medicine{
	public Tablet1(String string, double d, String string2) {
		// TODO Auto-generated constructor stub
	}

	public void displayLabel() {
		System.out.println("Take with water");
	}

}
