/**
 * 
 */
/**
 * @author diot
 *
 */
module abhi.com {
}