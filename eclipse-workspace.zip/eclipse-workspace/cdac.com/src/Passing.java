
public class Passing {

}
