
public class Tablet {

}
