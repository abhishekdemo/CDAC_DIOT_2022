
public class Abstract {

}
