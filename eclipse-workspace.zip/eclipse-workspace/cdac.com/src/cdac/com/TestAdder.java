package cdac.com;

public class TestAdder {
	public  static void main(String[] args) {
		System.out.println(Adder.add(10,20));

}
}
// class