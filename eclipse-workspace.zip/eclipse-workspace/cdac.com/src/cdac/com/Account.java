package cdac.com;

public class Account {
	
	int aid ,bal;
	 static int minbal=6000;// static varaibel
	String name;
	public Account(int aid, int bal,  String name) {
		super();
		this.aid = aid;
		this.bal = bal;
		//this.minbal = minbal;
		this.name = name;
	}
	public  static void changeMinbal(int newMinBal)
	{
		minbal=newMinBal;
		
	}
	@Override
	public String toString() {
		return "Account [aid=" + aid + ", bal=" + bal + ", minbal=" + minbal + ", name=" + name + "]";
	}
	public static void main(String[] args) {
		Account a1=new Account(1,1000,"aaa");
		Account a2=new Account(1,222222,"bbb");
		minbal(7000);
		
		System.out.println(a1);
		System.out.println(a2);
		
	}

}
