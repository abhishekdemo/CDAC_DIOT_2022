package cdac.com;

public class demo {
	
	int i=100;
	static int j=100;
	public  void m1()
	{
		System.out.println("in main"+i +j);
	}
	public  void m2()
	{
		System.out.println("in main"+j);
	}

	public static void main(String[] args) {
		
		demo d1=new demo();
		d1.m1();
		m2();
		System.out.println("hello i am here");
		
	}
}
