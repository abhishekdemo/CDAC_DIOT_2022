package cdac.com;
// bank accout details
public class Demo08 {
	// acctid,accname,balance,cont_detais
	
	int custid;
	Name custmer;
	public Demo08(int custid, Name custmer, ContactDetails cd, int rating) {
		super();
		this.custid = custid;
		this.custmer = custmer;
		this.cd = cd;
		this.rating = rating;
	}
	ContactDetails cd;
	int rating;
	public String toString()
	{
		return "Custmer["custid="+custid,"name="+Name,"rating="+rating]";
	}
	
	public static void main(String[] args) {
		ContactDetails cd1= new ContactDetails("ahbok","1223333");
		Name name=new Name("sdd","sdhu");
		Custmer c =new Custmer(10,name,cd1,4);
	}
	
	
	

}
