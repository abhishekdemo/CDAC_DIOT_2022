package cdac.com.in;

public class Tablet12 extends Medicine {
	 
	public Tablet12(double price,String date) {
		super(price,date);
		
	}
	
	@Override
	public String toStr() {
		return "Tablet12 []";
	}
	


}
