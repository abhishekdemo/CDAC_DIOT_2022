package cdac.com.in;

public class Syrup extends Medicine {
	
	public Syrup(double price ,String date)
	{
		super(price,date);
	}
	
	
	@Override
	public String toString() {
		return "Syrup []";
	}


	public void getLabel() {
		System.out.println("this is not valid precaution");
	}

}
