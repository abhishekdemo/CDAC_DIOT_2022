package cdac.com.in;

public class Onitnet extends Medicine {
	
	public Onitnet(double price ,String date)
	{
		super(price,date);
	}
	
	
	@Override
	public String toString() {
		return "Onitnet []";
	}


	public void getLabel() {
		System.out.println("this is not valid precaution");
	}

}
