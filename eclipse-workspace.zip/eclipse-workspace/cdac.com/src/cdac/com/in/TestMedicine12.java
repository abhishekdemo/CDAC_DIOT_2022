package cdac.com.in;

public class TestMedicine12 {
	public static void main(String[] args) {
		
		Medicine m1 =new Tablet12(345.00,"24-2-22");
		Medicine m2=new Onitnet(345.00,"12-2-22");
		Medicine m3=new Syrup(345.00,"14-2-22");
		
		Medicine []list =new Medicine[3];
		list[0]=m1;
		list[1]=m2;
		list[2]=m3;
		
		for(Medicine m:list)
		{
		m.getDetails();
		m.getLabel();
		System.out.println("-----------------");
		}
	}

}
