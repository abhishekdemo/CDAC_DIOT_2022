package cdac.com.in;

public abstract class Medicine {
	double price;
	String date;
	public  Medicine(double price, String date)
	{
		this.price=price;
		this.date=date;
	}
	
	
	
public String getDetails() {
	return "Medicine[price="+price+",date="+date+"]";
	
	
}

public void getLabel()
{

}
	
}