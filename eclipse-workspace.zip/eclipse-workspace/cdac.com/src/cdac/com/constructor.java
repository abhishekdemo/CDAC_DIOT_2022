package cdac.com;

public class constructor {
	
	public static void main(String[] args) {
		System.out.println("hello");
	}

}
