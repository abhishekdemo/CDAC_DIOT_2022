package cdac.com;

public class name {
	string name,fname,lnmae;

	@Override
	public String toString() {
		return "name []";
	}

	public name() {
		super();
		// TODO Auto-generated constructor stub
	}

}
