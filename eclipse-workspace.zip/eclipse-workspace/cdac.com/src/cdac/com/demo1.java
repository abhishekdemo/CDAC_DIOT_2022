package cdac.com;

public class demo1 {
	public static void main(String[] args) {
		/*String s1="Hello World";
		//String s2=new String("Hello World");
		System.out.println(s1);
		/*s1+="Yogesh";
		System.out.println(s1); */
		/*System.out.println(s1.length());
		System.out.println(s1.charAt(3));
		System.out.println(s1.indexOf("orl"));
		System.out.println(s1.toLowerCase());
		System.out.println(s1.toUpperCase());
	}*/


		String s1="Hello#world#to#the#world";
		System.out.println(s1);

		String[] arr=s1.split("#");
			for(s)
		System.out.println(s1);

}
}