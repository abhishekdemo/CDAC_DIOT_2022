package cdac.com;

public class adder {

}
