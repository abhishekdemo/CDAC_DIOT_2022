package cdac.com;

public class UseProduct {
	
	int productid;
	String description;
	double price;
	
	public void displayDetails(int productid,String description,double price)
	{
		this.productid=productid;
		this.description=description;
		this.price=price;
		
	}
	
	public static void main(String[] args) {
		UseProduct p1=new UseProduct();
		System.out.println(p1);
		
	}

}
