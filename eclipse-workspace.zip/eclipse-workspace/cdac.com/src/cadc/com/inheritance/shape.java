package cadc.com.inheritance;

public abstract class shape {
	String color;
	public String getcolor()
	{
		return color;
	}
	
	public void setcolor(String color)
	{
		this.color=color;
	}
	public abstract void draw();
	
}
