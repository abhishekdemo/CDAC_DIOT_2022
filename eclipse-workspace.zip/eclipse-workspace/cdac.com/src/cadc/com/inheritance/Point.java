package cadc.com.inheritance;

public class Point extends shape{
	public void draw() { //implementing abstarct method
		System.out.println(" drawing a point ");
		
	}
	
	public static void main(String[] args) {
		shape s1=new Point();
		s1.setcolor("blue");
		System.out.println(s1.getcolor());
		s1.draw();
	}

}
