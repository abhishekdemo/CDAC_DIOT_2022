package cadc.com.inheritance;

public class Circle extends Point {
	public void draw() { //overriding abstract method
		System.out.println(" drawing a circle");
		
	}
	public static void main(String[] args) {
		
	
	shape s1=new Point();
	s1.draw();
	
	shape s2=new Circle();
	
	s2.draw();

}
}
