package cadc.com;

public class practice {
	
	public static void main(String[] args) {
		int a=21;
		System.out.println("this is your number="+a);
		
	}

}
