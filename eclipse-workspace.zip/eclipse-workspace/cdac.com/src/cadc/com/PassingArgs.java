package cadc.com;


public class PassingArgs {
	
		public static void m1(int i) {
			i++;
		}
	public static void main(String[] args) {
		int j=10;
		m1(j);
		System.out.println(j);
	}
	}



