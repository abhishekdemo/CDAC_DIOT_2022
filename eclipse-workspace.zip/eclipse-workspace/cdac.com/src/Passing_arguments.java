
public class Passing_arguments {

}
