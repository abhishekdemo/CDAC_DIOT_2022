/**
 * 
 */
/**
 * @author diot
 *
 */
module first.com {
}