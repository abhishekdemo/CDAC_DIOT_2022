/*  
	Write a C program to learn Pointers Operators.
	Pointer have Two Operators
	1.*(asterick)-It gives value of a variable
	2.&(ampercentage)-It gives an address of a variable


*/

#include<stdio.h>
int main()
{
	int iNum=100;
	
	

	printf("\nThe value of iNum is:%ld\n",iNum);
	printf("\nThe Address of iNum is:%ld\n",&iNum);
	printf("\n..........................\n");



	//Assign the Adress of variable to pointer
	int* iPtr;
	iPtr=&iNum;

	printf("\nThe value of iNum using pointer is:%ld\n",*iPtr);
	printf("\nThe Address of iNum using pointer is:%ld\n",iPtr);
	printf("\nThe Address of Ptr is:%ld\n",&iPtr);
	printf("\n..........................\n");

	
	return 0;
}
