#include<stdio.h>
//Function Declaration
void Accept_Data(int*,int*,int*);
int main()
{
	int day,month,year;
	Accept_Data(&day,&month,&year);

	printf("Date:%d/%d/%d\n",day,month,year);


}
//Function Defination
void Accept_Data(int *dd,int *mm,int *yy)
{
	printf("Enter the day;");
	scanf("%d", dd);

	printf("Enter the month;");
	scanf("%d", mm);

	printf("Enter the year;");
	scanf("%d", yy);



}
