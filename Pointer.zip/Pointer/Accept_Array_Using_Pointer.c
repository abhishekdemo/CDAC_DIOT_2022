
#include<stdio.h>
void Accept_Array(int* aPtr);
void Display_Array(int* aPtr);

int main()
{
	int Arr[5];
	
	Accept_Array(Arr);
	Display_Array(Arr);

	return 0;
}
void Accept_Array(int* aPtr)
{
	printf("Enter the 5 Array Elements;");
	for(int i=0;i<5;i++)
	{
		scanf("%d",&aPtr[i]);
}
}
void Display_Array(int* aPtr)
	{
		printf("The five Array Elements are:");
		for(int i=0;i<5;i++)
{
		printf("%d",aPtr[i]);
	
}
}
