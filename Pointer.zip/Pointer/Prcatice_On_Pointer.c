/* Perform Arithmatic Operations Using Pointer
	Write a C program to perform Add,Sub,Multi and Div into calculate function and display the result of all the operations into main function.
*/

#include<stdio.h>

 void Calculate(int*,int*,int*,int*);
  int main()
  {
	int add,sub,mul,div;
    Calculation(&add,&sub,&mul,&div);
    printf("Addition : %d\n",add);
	printf("Substraction: %d\n",sub);
	printf("Multiplication: %d\n",mul);
	printf("Division : %d\n",div);

	
	

	return 0;

	


  }

void Calculate(int *a,int *s,int *m,int *d)
  {

	int iNum1,iNum2;
	printf("\nEnter the iNum1");
	scanf("%d",&iNum1);
	printf("\nEnter the iNum2");
	scanf("%d",&iNum2);


	*a=iNum1+iNum2;
	*s=iNum1-iNum2;
	*m=iNum1*iNum2;
	*d=iNum1/iNum2;
}

