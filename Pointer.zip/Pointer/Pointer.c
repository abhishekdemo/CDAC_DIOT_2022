// C Program-use of pointer concepts
#include<stdio.h>
int main()
  {
	//pointer declaration
	char *cPtr;
	int *iPtr;
	float *fPtr;
	void *Ptr;

	printf("\n-------------\n");
	printf("sizeof character pointer is:%ld\n",sizeof(cPtr));
	printf("sizeof integer pointer is:%ld\n",sizeof(iPtr));
	printf("sizeof float pointer is:%ld\n",sizeof(fPtr));
	printf("sizeof void pointer is:%ld\n",sizeof(Ptr));
	printf("\n-------------\n");

	return 0;

  }
