  #include<stdio.h>
  void Swap(int*,int*);
  int main()
  {
	int iNum1,iNum2;
	printf("\n Enter the iNum1;");
	scanf("%d",&iNum1);
	printf("\n Enter the iNum2;");
	scanf("%d",&iNum2);

	Swap(&iNum1,&iNum2);

	printf("\nAfter Swapping:\n");
	printf("iNum1:%d\n",iNum1);
	printf("iNum2:%d\n",iNum2);
	printf("\n----------\n");

	return 0;

	


  }

  void Swap(int *iNum1,int *iNum2)
  {

	int temp;
	temp=*iNum1;
	*iNum1=*iNum2;
	*iNum2=temp;

	

	
	
  }


	



