# Angular
Concepts of Angular <br>
# To install Angular <br>
    sudo npm cache clean -f 
    sudo npm install -g n 
    sudo n stable 

    sudo n 16.18.0 <br>
    
    npm uninstall -g @angular/cli.
    sudo npm install -g @angular/cli 

 # Open your folder and in terminal 
    ng new app-name 
 # Open app-name folder in terminal 
    ng serve 
# To Create new component  
    ng g c component_name <br>
# To Create new service  
    ng g s service_name <br>


# node_modules not available in any folder

<br>


<h2>https://stackoverflow.com/questions/8191459/how-do-i-update-node-js</h2>
<br>
** hash -r
