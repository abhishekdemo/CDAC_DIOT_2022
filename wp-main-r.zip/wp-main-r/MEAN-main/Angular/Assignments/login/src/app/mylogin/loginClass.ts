export interface iLoginClass{
    uname:string,
    passwd:string
}