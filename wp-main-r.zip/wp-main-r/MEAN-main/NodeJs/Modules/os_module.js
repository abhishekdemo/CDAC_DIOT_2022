var os = require("os")          // import os modules

console.log(os.hostname());
console.log(os.platform());
console.log(os.arch());