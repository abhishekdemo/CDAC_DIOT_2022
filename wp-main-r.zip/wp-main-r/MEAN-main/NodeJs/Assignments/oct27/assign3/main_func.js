let my_arith = require("./mymodule");       // import module

console.log("\n---------------------------------------------------\n");
my_arith.Factorial(5);

console.log("\n---------------------------------------------------\n");
my_arith.isPrime(7);
my_arith.isPrime(8);

console.log("\n---------------------------------------------------\n");
my_arith.myTable(4);

console.log("\n---------------------------------------------------\n");