let my_greet = require("./greet");

my_greet.greet();