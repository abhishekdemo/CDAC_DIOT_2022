/***************************************
 * @name class module
 * @date 27/oct/2022
 * @brief create a class and export it.
***************************************/
class Emp{
    display()
    {
        console.log("Class insertion");
    }
}

module.exports = Emp