var msg = "Hello J2"

function greet()
{
    document.write(msg)
}