
"""
    print main menu
"""
def main_menu():
    print("Operations on ")
    print("Operations on ")
    print("Operations on ")
    print("Operations on ")
    print("Operations on ")
    print("Enter ")

