# Python
Concept of python using code
