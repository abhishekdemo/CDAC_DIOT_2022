"""x, y = input("Enter two values: ").split()
print("Number of boys: ", x)
print("Number of girls: ", y)

x = list(map(int, input("Enter multiple values: ").split()))
print("List of students: ", x)"""

a, b = input("Enter two values: ").split()
print("First number is {} and second number is {}".format(a, b))
print()
