num=int(input("enter tne number :"))
cnt= 2
while(cnt<=num):
    cnt+=1
    divisor=2
    while(divisor<=cnt//2):
        if cuu
        print("is not prime")
        break
        
  

        

    
    
 