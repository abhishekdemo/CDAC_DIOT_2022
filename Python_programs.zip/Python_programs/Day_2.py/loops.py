from operator import truediv
from pickle import TRUE
from pydoc import doc


'''am_i_alive =True
age = 0
while(am_i_alive):
    print("my age is ",age)
    age += 1
    if(age==20):
        am_i_alive= False'''

#using do_while

"""am_i_alive =True
age = 0
while True:
    print("my age is",age)
    age = age+1
    if(age==20):
        am_i_alive= False
        if(not am_i_alive):
            break      """



 




