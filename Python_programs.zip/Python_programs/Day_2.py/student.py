"""Name = str(input("enter Name :"))
age =int(input("Enter age:"))
roll_no=int(input("Enter roll no:"))
marks=int(input("Enter mark in fav sub:"))
total_marks=int(input("Enter total marks:"))
Favourite_sub =str(input("enter favourite sub :"))
print("name is",Name.lower(),Name.upper(),Name.capitalize())
print("Age is:",age)
print("Roll no:",roll_no)
print("marks in fav sub:",(marks/100)*100)
print("Welcome Mr",Name.upper(),"to the world of programming.It will fun to be here.You could use your fav sub",Favourite_sub,"to your advantage here")"""
from re import sub
def camel_case(s):
  s = sub(r"(_|-)+", " ", s).title().replace(" ", "")
  return ''.join([s[0].lower(), s[1:]])

name = input("Please enter Name   ")
age = int(input("Please enter Age"))
rollno = int(input("Please enter Rollno"))
str_dob = input("Please enter date of birth in dd/mm/yyyy")


fav_sub = input("Please enter your favourite subject ")
marks_fav_sub = int(input("Please enter marks in that favourite subject"))
total_marks = int(input("Please enter Total marks in the semester"))


print(type(name))
print("Your original name is   ", name)
print("Your name Sentence case is  ", name.capitalize())
print("Your name is Camel case is   ", camel_case(name))
print("Your name is Upper case is ", name.upper())

from datetime import datetime
import calendar ;

print("Your age is " , age )
print("Your rollno is " , rollno )
print("Your date in string format is  " , str_dob )

dt_dob= datetime.strptime(str_dob, '%d/%m/%Y')
print("Year is " , dt_dob.year)
print( "The day is " , calendar.day_name[dt_dob.isoweekday()-1])



print("Your favorite subject is " , fav_sub )
print("Your marks in favourite subject is " , marks_fav_sub )
print("Your total_marks are " , total_marks )

print ( "Percentage of marks of his total marks for his favourite subject in that semester is ",(marks_fav_sub/total_marks*100))


print(
"Welcome Mr/Ms " , name,"  to the world of programming , It will fun to be here \n You could use your favourite subject " ,  fav_sub, "to your advantage here"
)



