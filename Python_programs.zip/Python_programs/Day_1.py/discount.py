discount= float(input("please enter discunt :"))
fare= float(input("please enter fare :"))
destination= str(input("please enter destination :"))
destination2= str(input("please enter destination 2 :"))
print("fare_rate",fare-(fare*discount)/100)


