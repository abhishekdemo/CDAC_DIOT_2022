from functools import update_wrapper
from unittest import case


string = input("enter the the string in lower case :")


print(string.lower())

