#Accept two no. from user and print thier add,square with 2,x raise to y.


x = input("Enter the  number :")
y = input("Enter the  number :")
Raised_to = float(x)**float(y)
print("Raised_to",Raised_to)
print(type)

#addition = int(x)+int(y)
#square = int(x)*int(y)
