


raised_salary_percentage =int(input("please enter salary percentage : "))
Name = 'Ram'
existing_salary = 1000
print("raised_salary_percentage",existing_salary+(existing_salary*raised_salary_percentage)/100) 
