x=input("enter your height in foot:")
height=int(x)*30
print("your height in cms is",height)