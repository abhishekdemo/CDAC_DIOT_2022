Dollar=82
Amount=input(Amount*Dollar)
print("Amount",int(Dollar*82))