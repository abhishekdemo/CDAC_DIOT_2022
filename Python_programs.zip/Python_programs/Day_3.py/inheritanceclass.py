# use inheritance to solve this problem
class creature:
    #class variables and methods
    category_name = "mammal" ,

    @classmethod
    def get_category_name(cls):
        return cls.category_name

    @classmethod
    def set_category_name(cls,cat_name):
        cls.category_name = cat_name

    # instance variables 
    def __init__(self,rcv_unique_id,rcv_gender,rcv_current_activity):
        self.unique_id = rcv_unique_id,
        self.gender= rcv_gender,
        self.current_activity = rcv_current_activity,
        

    #instance methods()
    def get_creature_details(self):
        print(
        f"{self.designation} Details are {self.unique_id} --> {self.gender}--> {self.current_activity}" )
	
    def get_creature_details(self):
        print(
        f"{self.designation} Details are {self.unique_id} --> {self.gender}--> {self.current_activity}" )
    def get_sleep(self):
        print("i am sleeping")
    def get_eat(self):
        print("i am eating")

class human(creature):

    #instance variables 
    def __init__(self,rcv_age,rcv_name,rcv_city,rcv_unique_id,rcv_gender,rcv_current_activity):
        super().__init__(self,rcv_age,rcv_name,rcv_city,self,rcv_unique_id,rcv_gender,rcv_current_activity)
        self.age= rcv_age,
        self.name = rcv_name,
        self.city = rcv_city
    # instance methods()
    def get_human_details(self):
        print(
        f"{self.designation} Details are {self.age} --> {self.name}--> {self.current_city}" )

    def get_play(self):
        print("i am playing")

    def get_work(self):
        print("i am working")

    def get_human_display_details(self):
        print(
        f"{self.designation} Details are {self.age} --> {self.name}--> {self.current_city}" )
    def main():
        print("I am in main")

        swapnil= human(22,"swapnil",'pune')
        print(swapnil.human_age)
        print( swapnil.human_name)
        print(swapnil.get_human_city)      
# start_current_activity(rcv_current_activity) --> starts either one of the activity eat()/sleep()/work()/play
	 #raise an exception if Human is said to perform any other activity#
    def get_human_current_activity():
        rcv_receive_actitivity=0
        if (human.get_play()):
            print("playing")
        elif(human.get_work):
            print("working")
        elif(human.get_sleep):
            print("sleeping")
        elif(human.get_eat):
            print("eating")
        else(human.get rcv_receive_actitivity):
            print("no activity")