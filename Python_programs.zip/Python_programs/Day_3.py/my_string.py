#my_tuples =('y','o','g','e','s','h')
#my_list =['y','o','g','e','s','h']
my_string="yogesh"
print("my zeroth element",my_string[0])
print("my third element",my_string[3])
print("using :",my_string[:])
print("using :",my_string[2:])
print("using :",my_string[:3])
print("using :",my_string[:4])
print("using :",my_string[0:5:2])

#using slice object
print("using slice object:",my_string[slice(2,4,1)])
print("using slice object:",my_string[slice(3,2,1)])
print("using slice object:",my_string[slice(2,4,)])
print("using slice object:",my_string[slice(4)])
print(min(my_string))
print(max(my_string))