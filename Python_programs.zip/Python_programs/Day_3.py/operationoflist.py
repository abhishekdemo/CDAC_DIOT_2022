
 
def add_two_lists(input_list1):
        #Take the second list from the user for this operation
        input_list2 = list(input("Please enter the values for the second list"))

        is_number_list = input("Are the number lists: Type Y/N").upper

        list1_len = len(input_list1)
        list2_len = len(input_list2)

        new_list=[]
        for i in range(0,max(list1_len,list2_len)):
            if is_number_list=='Y':
                new_list.append( int(input_list1[i])+int(input_list1[i]))
            else:
                new_list.append( input_list1[i]+input_list1[i])

        print(new_list)

def element_exists(input_list,element_to_search):
    try:
        print("Number found on index " ,  input_list.index(element_to_search))
    except ValueError:
        raise ValueError("Number not present in the list ")
        #Note : raise an exception if the element is not found in the list

def func_choice1():
    input_list1 = list(input("Please enter the values for the first list"))
    print("1 Add Two lists in order of their insert")
    print("2 Check if the element is present in the list")
    print("3 Append to the list ")
    sub_operation = int(input("Please enter operation would you like to perform"))
    
    if sub_operation ==1:
          add_two_lists(input_list1)              
    elif sub_operation ==2:
        element_to_search = input("Please Input element that you would like to search")
        element_exists(input_list1,element_to_search)
    elif sub_operation ==3:
        #Take the Slice or individual element to add to the first list	
        to_append_element = input("individual element to add to the first list")
        input_list1.append(to_append_element)
        print("Element Added :" , input_list1 )
    return True

def func_choice2():
    pass 

def func_choice3():
    pass 

def func_choice4():
    pass 

while(True):
    print("DIOT STORE")
    print("Welcome User , What would you like to do today?")
    print("1) Operations on List")
    print("2) Operations on Dictionary")
    print("3) Operations on Set")
    print("4) Operations on strings ")
    print("5) Exit")
    choice = int(input("Please enter you choice"))
    
    if choice ==1:
        func_choice1() 
    elif choice ==2:
        func_choice2() 
    elif choice ==3:
        func_choice3()  
    elif choice ==4:
        func_choice4()  
    elif choice ==5:
        print("Thank you for using DIOT store today!!! Visit again")
        break
    else:
        print("Please enter correct choice")

        
     