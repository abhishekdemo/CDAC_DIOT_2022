class Person:
    
    Person_name = "jessa"    
    def __init__(self,rcv_name,rcv_sex,rcv_profession,rcv_work) -> None:
        self.Person_name = rcv_name
        
        self._Person_sex = rcv_sex
        self._Person_profession = rcv_profession
        self._Person_work=rcv_work
    def get_name(self):
        return self._Person_name

    def get_sex(self):
        return self._Person_sex


    def get_Person_profession(self):
        return self._Person_profession
    def get_Person_work(self):
        return self._Person_work
    
    Person_name = "jon"    
    def __init__(self,rcv_name,rcv_sex,rcv_profession,rcv_work) -> None:
        self.Person_name = rcv_name
        
        self._Person_sex = rcv_sex
        self._Person_profession = rcv_profession
        self._Person_work=rcv_work
    def get_name(self):
        return self._Person_name

    def get_sex(self):
        return self._Person_sex


    def get_Person_profession(self):
        return self._Person_profession
    def get_Person_work(self):
        return self._Person_work
    
   
    
def main():
    print("I am in object1")

    jessa= Person("jessa",'female','software engg','engg')
    print(jessa.person_name)
    print(jessa.Person_sex)
    print(jessa.get_Person_profession())
    print( jessa._Person_work())


    print("I am in object2")

    jon= Person("jon",'male','doctor','hospital')
    print(jon.Person_name(


    ))
    print( jon._Person_sex)
    print(jon.get_Person_profession())
    print( jon._Person_work())
    print("i am")


"""
    pratik= Student("Pratik",2,200,'Java')
    print(gaurav.student_name)
    print(gaurav.get_student_pocket_money())
    print("Before Enroll call ", gaurav.student_enrolled_coursename)
    gaurav.enroll("C")
    print("After Enroll call ", gaurav.student_enrolled_coursename)

    print("School name is",gaurav.school_name)
    Student.change_schoolname("Sunbeam")
    print("Gaurav School name is",gaurav.school_name)
    print("Pratik School name is",pratik.school_name)
"""
main()