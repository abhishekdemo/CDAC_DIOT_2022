class Student:
    
    school_name = "CDAC"    
    def __init__(self,rcv_name,rcv_rollno,rcv_pocket_money,rcv_course) -> None:
        self.student_name = rcv_name
        self._student_rollno = rcv_rollno
        self._student_pocket_money = rcv_pocket_money
        self._student_enrolled_coursename = rcv_course

    def get_enrolled_course(self):
        return self._student_enrolled_coursename

    def get_rollno(self):
        return self._student_rollno


    def get_student_pocket_money(self):
        return self._student_pocket_money

    def enroll(self,rcv_course_name):
        self._student_enrolled_coursename = rcv_course_name

    def unenroll(self):
        self._student_enrolled_coursename = None

    @classmethod
    def change_schoolname(cls,rcv_schoolname):
        cls.school_name = rcv_schoolname
def main():
    print("I am in main")

    gaurav= Student("Gaurav",1,100,'Python')
    print(gaurav.student_name)
    print( gaurav._student_rollno)
    print(gaurav.get_student_pocket_money())
    print("Before Enroll call ", gaurav.get_enrolled_course())
    gaurav.enroll("Scala")
    print("After Enroll call ", gaurav.get_enrolled_course())

"""
    pratik= Student("Pratik",2,200,'Java')
    print(gaurav.student_name)
    print(gaurav.get_student_pocket_money())
    print("Before Enroll call ", gaurav.student_enrolled_coursename)
    gaurav.enroll("C")
    print("After Enroll call ", gaurav.student_enrolled_coursename)

    print("School name is",gaurav.school_name)
    Student.change_schoolname("Sunbeam")
    print("Gaurav School name is",gaurav.school_name)
    print("Pratik School name is",pratik.school_name)
"""
main()