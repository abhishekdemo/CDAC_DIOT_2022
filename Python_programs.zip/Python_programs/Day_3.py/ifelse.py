x=int(input("Enter marks"))
if x<30:
    print("c")
elif x>=30 & x<90:
    print("B")
elif x>=90 & x<=100:
    print("A")
else:
    print("Invalid marks") 