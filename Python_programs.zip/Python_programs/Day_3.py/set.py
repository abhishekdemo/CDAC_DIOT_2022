set= {8,3,5}
set1={4,6,8}
a=set*set1
print(a)