def display(name,age):
    print(name,age)

    display(Yogesh,y)