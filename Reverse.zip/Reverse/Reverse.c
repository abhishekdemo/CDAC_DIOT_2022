#include"Reverse.h"
#include<stdio.h> 

void Reverse(int n)
{
int rev,temp; 
while(n>0)
{
  temp=n%10;
  rev=rev*10+temp;
  n=n/10;
}

printf("The Reverse of a %d is %d \n",n,rev);
}
