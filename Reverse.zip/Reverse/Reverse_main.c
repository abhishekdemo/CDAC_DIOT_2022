#include"Reverse.h"
#include<stdio.h>

int main()

{
  char ch;
 do 
{
 int n;
printf("Enter the number:");
scanf("%d",&n);

Reverse(n);

printf("\nDo you want to continue....Y/N:");
scanf("%c",&ch);
scanf("%c",&ch);
 
}while(ch=='y' || ch=='y');
return 0;
}
  

