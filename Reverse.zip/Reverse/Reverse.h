void Reverse(int n);
