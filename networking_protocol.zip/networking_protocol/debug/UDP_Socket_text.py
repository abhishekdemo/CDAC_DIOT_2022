import socket

localIP="127.0.0.1"
localport=20001
Buffersize=1024

msgFromServer="Hello UDP Client"
bytesToSend= str.encode(msgFromServer)

#create a datagram socket

UDPServerSocket=socket.socket(family=socket.AF_INET,type=socket.SOCK_DGRAM)

#Bind to adress and ip

UDPServerSocket.bind((localIP,localport))
print("UDP server up and listening")

#listen for incoming datagrams

while(True):
    bytesAddressPair=UDPServerSocket.recvfrom(Buffersize)
    message=bytesAddressPair[0]
    address=bytesAddressPair[1]

    clientMsg="Message from client:{}".format(message)
    clientIP="Client IP Address:{}".format(address)

    print(clientMsg)
    print(clientIP)

    UDPServerSocket.sendto(bytesToSend,address)