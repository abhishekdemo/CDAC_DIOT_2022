import socket
from _thread import *

host = '127.0.0.1'
port =1230
ThreadCount =0


def client_handler(connection):
    connection.send(str.encode('you are now connected to the reply server'))


    while True:
        data=connection.recv(2048)
        message=data.decoder('utf_8')
        if message == 'bye':
            break
        reply= f'Server:{message}'
        connection.sendall(str.encode(reply))

def accept_connection(ServerSocket):
    Client,address=ServerSocket.accept()
    print('connection to'+address[0]+ ':' + str (address[1]))

    start_new_thread(client_handler,(Client,))

def start_server (host,port):
    ServerSocket = socket.socket()
    try:
        ServerSocket.bind((host,port))
    except socket.error as e:
        print(str(e))
    print(f'server is listing on the port {port}')
    ServerSocket.listen()


    while True:
        accept_connection(ServerSocket)
start_server(host,port)