
public class first {

}
