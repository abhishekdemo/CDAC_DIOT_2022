#include<stdio.h>

int** Accept(int **m1, int **m2,int r,int c)
{
	printf("\nEnter the Element for 1st 2D-Matrix: \n");
	for(int i=0;i<3;i++)
}
