#include"Matrix_Operation.h"
#include<stdio.h>

int main()
{
	char ch;
	int row,col,choice;
	int** mat=NULL;
		do
	{
	
	printf("\n========MENU========\n");
	printf("\n1.Allocate Memory for Matrix\n");
	printf("\n2.Accept The Element:\n");
	printf("\n3.Display The Element :\n");
	printf("\n4.Add The Element :\n");
	printf("\n5.Sub The Element :\n");
	printf("\n6.Transpose The Element :\n");

	printf("\nEnter your choice : \n");
	scanf("%d",&choice);
	switch(choice)

