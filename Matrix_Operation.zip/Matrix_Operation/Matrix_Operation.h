//Function Declaration

//Allocate Function
int** Allocate(int** m1, int** m2,int r,int c);

//Accept Function
int** Accept(int** m1, int** m2,int r,int c);

//Add Function
int** Addition(int** m1, int** m2,int r,int c);

//Sub Function
int** Subtraction(int** m1, int** m2,int r,int c);

//Transpose Function
int** Transpose(int** m1, int** m2,int r,int c);

//Display Function
int** Display(int** m1, int** m2,int r,int c);
