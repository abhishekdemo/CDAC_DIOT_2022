#include"queue.h"
#include<stdio.h>
#include<stdbool.h>
	bool queue_underflow(queue* q);
{
	int que_size=sizeof(q->arr) / sizeof(int);
	//printf("Total elements size of queue  is:%d\n",stack_size);

	if(q->Front==queue_size-1)
	return true;
	else
	return false;
}
	bool queue_overflow(queue* q);
{
	if(q->Top==-1)
	return true;
	else
	return false;
}
	void enqueue(queue* q);
{
	if(!queue_Overflow(q))
{
	printf("\nEnter the value to queue:\n");
	scanf("%d",&q->arr[++q->real]);
}
	else
{
	printf("\n queue is full....!!\n");

}
}
	void dequeue(queue* q);
{
	if(!queue_Underflow(q))
{
	printf("\ndequeue value from queue is:%d\n",q->arr[++q->front]);

}
	else
{
	printf("\n queue is empty....!!\n");
}
}
	
}
