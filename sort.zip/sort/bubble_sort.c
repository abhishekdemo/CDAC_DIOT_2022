// Write a C program to accept the array and sort the given array values.

#include<stdio.h>
#include<string.h>
int main()
{
	int arr[5];
	char ch,y;
	int i;
	do
	{
		printf("Enter the array elements:\n");
		for(int i=0;i<5;i++)
	{
		printf("arr[%d]",i);
		scanf("%d",&arr[i]);
	}		
	
		printf("Before sorting array values are\n");
		for(int i=0;i<5;i++)
	{
		printf("%d",arr[i]);
	}
}while(ch==y || ch==y);
	
		printf("%d",arr[i]);
	}
	
		printf("\nDo you want to continue:y/n");
		scanf("%c",&ch);
		scanf("%c",&ch);
}while(ch==y || ch==y)
	
	return 0;
}
