var emps=["joy","Meena","Anne","Xi","veena"]
for(arr of emps){
    

}
console.log(len(emps))