public class overloading {
    

    public int add(Int a,int b){

        return a+b;
    }
    public String add(String a,String b){

        return a+b;

    public static void main(String[] args) {
        Adder a1=new Adder();
        System.out.println(a1.add(10,20));
        System.out.println(a1.add("Yogesh","Mehetre"));
    }

}
