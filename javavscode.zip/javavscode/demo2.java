import java.io.IOError;

public class demo2 {

    public demo2() {
    }

}
    

