// A Program to send a PUT Request
const coap = require('coap');

const req = coap.request({
    host:"127.0.0.1",
    port: 5683,
    pathname: "/diot",
    method: 'PUT'
})
req.setOption("Content-Format","application/json")
// kitna size rkhna h ,
req.setOption("Block1",Buffer.alloc(0x2))
// payload mesaage rakha h 

const payload ="{'name':'Hello'}"
req.write(payload)
// this is a call back koption for providing communcation

  req.on('response', (res) => {
    console.log(res.code)
    // this is output of the pipe that is provide to you
    // jese jese byte m data upload hota vse hi creat hota h
    res.pipe(process.stdout)
    res.on('end', () => {
      process.exit(0)
    })
  })

  req.end()