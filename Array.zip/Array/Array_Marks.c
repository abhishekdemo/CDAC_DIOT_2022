/*Marks of 5 subjects*/
#include<stdio.h>

int main()
{
	int avg,sum=0;
	int i;
	int marks[5];
	int total_ele_arr= sizeof(marks)/sizeof(int);
	for(i=0;i<total_ele_arr;i++)
{
	printf("\nEnter Marks");
	scanf("%d",&marks[i]);
}
	for(i=0;i<=4;i++)

	sum=sum+marks[i];
	avg=sum/5;

	printf("\nAverage Marks=%d\n",avg);
	return 0;
}
