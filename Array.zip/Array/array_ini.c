#include<stdio.h>
int main()
{
	int i;
	int num[6]={2,4,12,5,15,45};
	
	int total_ele_arr = sizeof(num)/sizeof(int);
	printf("The values are:\n");
	for(i=0;i < total_ele_arr;i++)
{
	printf("%d ",num[i]);
}

printf("\n---------------\n");
	
	int n[]={2,4,12,5,15,45};

	total_ele_arr = sizeof(n)/sizeof(int);
	printf("The values are:\n");
	for(i=0;i < total_ele_arr;i++)
{
	printf("%d ",n[i]);
}

printf("\n---------------\n");

	float press[]={12.3,34.2,-23.4,-11.3};	

	total_ele_arr = sizeof(press)/sizeof(int);
	printf("The values are:\n");
	for(i=0;i < total_ele_arr;i++)
{
	printf("%.2f ",press[i]);

}

return 0;
}





