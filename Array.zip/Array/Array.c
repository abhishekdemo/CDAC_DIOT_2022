/* Write a C Program to Demonstrate Array */

#include<stdio.h>
int main()
{
	//int iNum1,iNum2,iNum3,iNum4,iNum5;
	//Array Declaration
	int arr[5];
	printf("\nSize of Array:%d\n",sizeof(&arr));
	printf("\nSize of Array:%d\n",sizeof(arr));
	
	int total_arr_ele=sizeof(&arr)/sizeof(int);
	printf("\nTotal elements in Array:%d\n",total_arr_ele);
	printf("\nDefault value stored in Array:%d\n");
	for(int i=0;i<total_arr_ele;i++)
	{
	  printf("arr[%ld]=%ld\n",i,arr[i]);
	}
 return 0;
}
