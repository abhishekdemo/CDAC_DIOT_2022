
input("wingsoffire|APJAbdulkalam|2010")
input("harrypotter|JKrowling2010")


print("input")


