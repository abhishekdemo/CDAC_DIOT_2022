#   create a string  input #

from operator import concat


a=input("Enter string:")  # initalizing a string with parameter in console
word=input("Enter word:") #  initalizing a word to the input
  

b = a.count(word)
  

print ("Count of word is  : " +  str(b))  #concatinating the string