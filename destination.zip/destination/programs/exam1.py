a=input("Enter string:")
word=input("Enter word:")
  

b = a.count(word)
  

print ("Count of word is  : " +  str(b))
