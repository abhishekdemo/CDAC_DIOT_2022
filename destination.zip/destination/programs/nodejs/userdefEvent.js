var events=require('events')
var eventEmitter=new events.eventEmitter();