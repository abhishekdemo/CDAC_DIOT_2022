let os=require("os")
console.log(os.hostname())
console.log(os.arch())
console.log(os.platform())
