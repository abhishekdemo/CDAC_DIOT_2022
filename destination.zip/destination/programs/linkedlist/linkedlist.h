#ifndef Linked_List_H
#define Linked_List_H

struct Linked_List
{
int data;
struct Linked_List* Next;
};

typedef struct Linked_List Node;

//Allocate a memmory for struct Linked_List(Node)
Node* create_New_Node;
{	
	return;
}
Node* Add_New_Node_At_Begin(Node* head);
{	
	if(head==NULL)
	{
	head=Create_New_Node();
	return head;
	}
	else
	{
	Node* NewNode=Create_New_Node();
	tail->Next=NewNode;
	return NewNode;
	}
}
Node* Add_New_Node_At_End(Node* head);
{
	Node* temp=head;
    head=head->Next;
    free(temp)
	return head;
}
Node* Add_New_Node_In_Between(Node* head,int p);
{
	Node* curr=head;
	Node* prev;
	int count=1;
	
	while(count<p  && curr !=NULL)
{
	prev=curr;
	curr=curr->Next;
	count++;
}
	Node* NewNode=Create_New_Node();
	prev->Next=NewNode;
	NewNode->Next=curr;
	return head;
}
//Delete Node from List
Node* Delete_Node_At_Begin(Node* head);
{
	
	Node* temp=head;
    head=head->Next;
    free(temp)
	return head;
}
}
Node* Delete_Node_At_End(Node* head);
{
	
	Node* prev;
	while(head->Next !=NULL)
{
	prev=head;
	head=head->Next;
}
	free(head);
	prev->next=NULL;
	return prev;
int Node_count(Node* head)
{
	int count+0;
	if(head==NULL)
	return 0;
else
{
	while(head !=NULL)
{
	count++;
	head=head->Next;
}
}
	return count;
}
	
}
Node* Delete_Node_In_Between(Node* head,int p);
{
//CODE SNIPPET FOR 
	return head;
}

//Display_Linked_List
void Display_Linked_List(Node* head);
{
	printf("Linked List Elements are :\n");
	while(head->Next !=NULL)
	{
	printf("==>%d",head->Data);
}

#endif                                                                                                                                               
