#include"Linked_List_h"
#include<stdio.h>

int main()
{
	char ch;
	int choice;
	//create a pointer for linked list;
	Node* HEAD= NULL;
	Node* TAIL= NULL;
	do
	{
	printf("\n************MENU**********\n");
	printf("1.Add New node at begin of list...\n");
	printf("2.Add New node at end of list...\n");
	printf("3.Add New node in between of list by position...\n");
	printf("4.delete node at begin of list...\n");
	printf("5.delete node at end of list...\n");
	printf("6.delete node in between of list by position...\n");
	printf("7.Display the linked list...\n");
	
	printf("enter your choice")
	scanf("%d, &choce);
	printf("\n");
	
	
switch(choice)
	{
	case 1:
{
	if(HEAD==NULL)
	{
	HEAD=Add_New_node_at_begin(HEAD);
	TAIL=HEAD;
	}
	else
{
	HEAD=Add_New_node_at_begin(HEAD);
}

	
}
	break;
	case 2:
	{
	if(TAIL==NULL)
	{
	TAIL=Add_New_Node_At_End(TAIL);
	TAIL=HEAD;
	}	
	else
{
	TAIL=Add_New_Node_At_Begin(TAIL);
}
}
	break;
	case 3:
{
	int pos;
	printf("enter the pos to add the new node:");
	scanf("%d",&pos);

	if(HEAD==NULL && pos==1)
{
	HEAD=Add_New_Node_At_Begin(HEAD);
	TAIL=HEAD;
}
	else if(HEAD !=NULL && POS==1)
{
	HEAD=Add_New_Node_At_Begin(HEAD);
}
	else if(pos>1 && pos <=Node_count(HEAD)
{
	HEAD=Add_New_Node_At_Begin(HEAD,pos);
}
	else if (pos==Node_count(HEAD));
{
	TAIL=Add_New_Node_At_Begin(HEAD);
}
else
{

	printf("%d position is not present
	break;
	case 4:
{
	if(HEAD==NULL)
{
	printf("LIST IS Empty.....!\n");
}
	else if(HEAD->Next==NULL)
{
	free(HEAD);
	HEAD=TAIL=NULL;
}	
  else
{
	HEAD=Delete_node_at_begin(HEAD);
}
}

	break;
	case 5:
{
	if(HEAD==NULL)
{
printf("list is empty.....!\n");
}
	else if(HEAD->Next==NULL)
{
	free(HEAD);
	HEAD=TAIL=NULL;
}	
 	 else
{
	HEAD=Delete_node_at_end(HEAD);
}
}

	break;
	case 6:
{
	int count=node_count(HEAD);
	int pos=0;
	printf("\n enter the position of new node:\n");
	scanf("%d",&pos);
	if(pos==1)
	{
	if(count==0)
	{
	printf("list is empty....\n");
		}
	else if (pos==1 && count==1)
	{
	HEAD=delete_node_in_between(head,pos);

	}
	else
		{
	printf("new node position is not matiching");
	}
	}
	break;

	
	case 7:
	{
	if(HEAD==NULL)
	{
	printf("List is Empty....\n")
	}
	else
	{
	Display_Linked_List(HEAD);
	}
	
	}	
	break;
	default:
	printf("INVALID CHOICE..\n");
	break;
	}
	printf("do you want to continu....Y/N \n");
	scanf("%c",&ch);
}
	while(ch=='y'  || ch=='Y');
	return 0;
	
	
}


}

	break;
	return 0;
}

