#include"Linked_List_h"
#include<stdio.h>

 //Allocate amemmory for struct Linked_List(Node)
Node* create_New_Node()
{
	Node* NewNode=(Node*)malloc(sizeof(Node));
	if(NewNode != NULL)
	printf("\nEnter the value :");
	scanf("%d",&NewNode->Data);
	NewNode->Next= NULL;

} 
	else
	{
	printf("\n OS fail to allocate new memory....\n");
	}
	return NewNode;
}
