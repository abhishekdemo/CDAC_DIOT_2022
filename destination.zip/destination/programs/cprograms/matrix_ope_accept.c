#include<stdio.h>
int Accept_matrix(int**,m,int r,int c)
	{
	printf("\nEnter the elements for first 2D-Matrix:\n");
	for(int i=0;i<r;i++)
	{
	for(int j=0;j<c;j++)
	{
	scanf("%d",&m[i][j]);
	}
	}
	printf("\n---------------\n");
}
