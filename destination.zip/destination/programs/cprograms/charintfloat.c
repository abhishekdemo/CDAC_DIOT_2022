/*write c program to declare and accept charactor,int and float daratype*/
#include<stdio.h>
int main()
{
char ch1,ch2,ch3;
int inum1,inum2,inum3;
float fnum1,fnum2;
double dnum1,dnum2,dnum3;
printf("enter char,float,int on screen ");
printf("size of data type is %d\n",sizeof(char));
printf("size of data type is %d\n",sizeof(int));
printf("size of data type is %d\n",sizeof(float));
printf("size of data type is %d\n",sizeof(double));
scanf("%c",ch1);
scanf("%c",ch1);
scanf("%c",ch1);
return 0;
}
