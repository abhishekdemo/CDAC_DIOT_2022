/* write a c program to print the number from 1 to 10*/
#include<stdio.h>
int main()
{
	int inum1=1;
	while(inum1<=10)
	{
	printf("%d",inum1);
	inum1++;
	}
	return 0;
}
