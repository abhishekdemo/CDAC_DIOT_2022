/* write a c program to print the number from 1 to 10 using  for loop.*/

#include<stdio.h>
int main()
{
int inum;
//use for loop
for(inum+1;inum<=10;inum++)
{
printf("inum=%d\n",inum);
}
return 0;
}

