/* write a program to accept ascii character
*/
#include <stdio.h>
int main()
{
	char ch;
	printf("\enter the ascii character:\n");	
	scanf("%c",&ch);
	printf("ascii value for %c is %d:",ch,ch);
	return 0 ;
}
