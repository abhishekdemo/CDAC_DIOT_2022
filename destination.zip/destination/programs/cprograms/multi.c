#include<stdio.h>
int main()
{
int P, Q, total;
printf(" Enter the value of P: ");
scanf("%d", &P);
printf(" Enter the value of Q: ");
scanf("%d", &Q);
total = P * Q;
printf("%d", total);
return 0;
}
