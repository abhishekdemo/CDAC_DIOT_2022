/*
write a c program to accept student information like student_rollno,student_name,student_percentage etc. and  Display on console.
*/
#include<stdio.h>
#include<string.h>
//Struct Declaration-syntax
struct student
{
	int Roll_no;
	char Name[15];
	float Percentage;
};
//create short name for structure
//syntax==>typedef oldname newname;
	typedef struct student student;

//function declaration
void accept_student_details(student *s)
void display_student_details(student *s)
int main()
{
//student variable declaration
student s1;
accept_student_details(s1);

display_student_details(s2);
}
//function defination
void accept_student_details(student *s)
{
printf("\nenter the student details\n");
	printf("\nenter the roll no.:\n");
	scanf("%d",&s1->Roll_no);

	printf("enter name of student:\n");
	scanf("%s",&s1->Name);
	scanf("%s",&s1->Name);

	printf("enter the Percentage of the student:\n");
	scanf("%f",&s1->Percentage);

//student

printf("\n Student Details are:\n");
	printf("\n Roll no:%d\n",s1.Roll_no);
	printf("\n Student Name:%s\n",s1.Name);
	printf("\n Student Percentage:%.2f\n",s1.Percentage);
