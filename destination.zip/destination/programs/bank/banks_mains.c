#include"bank_database.h"
#include<stdio.h>

int main()
{
int choice;
char ch;
//declare array of students
bank b[5];

do
{
printf("\n********MENU*******\n");
printf("\n1.accept bank details\n");
printf("\n2.print the account no and name of each customer with balance below rs.100\n");
printf("\n3.print \n");
printf("\n the balance is insufficient for the specified withdrawal\n");
scanf("%d",&choice);
switch(choice)

{
case 1:
accept_bank_details(s);
break;
case 2:
print_the_account_by perticular_joining_year(s);
break;
case 3:
print_all_student_by perticular_roll_no(s);

break;
default:

