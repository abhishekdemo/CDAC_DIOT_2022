include<stdio.h>

#include"bank_database.h"
//accept bank account details
void accept_bank account_details(bank* sptr)
{
for(int i=0;i<5;i++)
{
	printf("\n------------\n");
printf("\n enter the %d bank details:\n",i+1);
printf(\n--------------\n");
printf("bank account number:");
scanf("%d",&sptr->account_number);
printf("account name":);
scanf("%s",sptr->name,strlen(sptr->name)+1);
printf("balance in account:");
scanf("%s",sptr->balance in account,strlen(sptr->balance in account)+1);
printf("student course name:");
scanf("%s",sptr->course,strlen(sptr->course)+1);
printf("student date of joining:");
scanf("%d%d%d",&sptr->year_of_joining.day,&sptr->year_of_joining.month,sptr->year_of_joning.year);
}
}
