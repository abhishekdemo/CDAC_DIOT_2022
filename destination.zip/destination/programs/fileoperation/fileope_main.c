#include<stdio.h>
int main()
{
	char ch;
	int choice;
	do
	{
	printf("1.creation of a new file\n");
	printf("2.opening an existing file\n");
	printf("3.reading from a file\n");
	printf("4.writting from a file\n");
	printf("5.moving to a specific location in a file(seeking)\n");
	printf("6.closing a file");
	
	printf("\n enter your choice")
	scanf("%d",&choice)

	switch(choice)
	{
	case 1:
	}
	print("do you want continue");
	fclose(fp)
	scanf("%c",ch1);
	scanf("%c,ch1);
	}
	while(ch=='y'   || ch=="Y");
	return 0;
	
	
