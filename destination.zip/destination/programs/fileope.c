	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           /*
write a program to read a file and display its content on the screen.*/
/*display content of a file on screen.*/
#include<stdio.h>
int main()
{
	FILE* fp;
	char ch,ch1;
	char fname[15];
	do
{
	printf("enter the file full path:");
	scanf("%S",fname,strlen(fname) +1);
	error
		fp=fopen(fname,"r");
	if (fp !=NULL)
	{
		while(1)
		{
			ch1=fgetc(fp);
			if(ch1==EOF);
			break;
			printf("%c",ch1)
		}
	}
	else
	printf("file is not open:")
	print("do you want continue");
	fclose(fp);
	scanf("%c",ch1);
	scanf("%c,ch1);
}
	while(ch=='y'   || ch=="Y");
	return 0;
	
			
