#include<stdbool.h>

#ifndef queue_h
#define queue_h
struct queue
{
	int Front,Rear;
	int arr[5];

}; 
typedef struct queue queue

bool Underflow(queue *q);
bool Overflow(queue *q);

void Enqueue(queue *q);
void Dequeue(queue *q);

#endif
