include<stdio.h>

#include"student_database.h"
//accept student details
void accept_student_details(student* sptr)
{
for(int i=0;i<5;i++)
{
	printf("\n------------\n");
printf("\n enter the %d student details:\n",i+1);
printf(\n--------------\n");
printf("student roll number:");
scanf("%d",&sptr->roll_number);
printf("student name":);
scanf("%s",sptr->name,strlen(sptr->name)+1);
printf("student department:");
scanf("%s",sptr->department,strlen(sptr->department)+1);
printf("student course name:");
scanf("%s",sptr->course,strlen(sptr->course)+1);
printf("student date of joining:");
scanf("%d%d%d",&sptr->year_of_joining.day,&sptr->year_of_joining.month,sptr->year_of_joning.year);
}
}
/*
write a function to print names of all students who joined in a particular year.
*/
int size_struct=0;
int j_year=0;
printf("enter the joining year\n");
scanf("%d",&j_year);

for(int i=0;i<5;i++)
{
if(j_year==sptr->year_of_joining.year)
{
printf("\nstudents dtails are:\n");
