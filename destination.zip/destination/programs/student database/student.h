#pragma once

struct book
{
int roll_number;
char name[15];
char name[15];
char department[15];
char course[10];
date year_of_joining;


};
//create short name of structure(alias)
typedef struct student student;

//function declaration
void accept_student_details(student* s);
void display_student_details(student* s);
