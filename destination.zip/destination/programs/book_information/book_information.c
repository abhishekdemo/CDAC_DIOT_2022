#include"book_information.h"

//function defination
void accept_book_details(book* b);
{
//Accept the book information.
	
	printf("\nenter the book details\n");
	printf("\nenter the book no.:\n");
	scanf("%d",&b1.book_no);

	printf("enter name of book:\n");
	scanf("%s",&b1.Name);
	scanf("%s",&b1.Name);

	printf("enter the Page no of book:\n");
	scanf("%f",&b1.page);

	printf("\n book Details are:\n");
	printf("\n book no:%d\n",b1.book_no);
	printf("\n book Name:%s\n",b1.Name);
	printf("\n book page no:%.2f\n",b1.page);





display_book_details(b1);
return 0;
}
