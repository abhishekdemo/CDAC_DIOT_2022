#include<stdio.h>
#include<malloc.h>

//   
struct Linked_List
  {
  int data;
  struct Linked_List* next;
  };

  typedef struct Linked_List node;

node* create_node(node* n);           //create a node //
node* store_data(node* n);            //create a node to store a  data// 
void display_data(node* n);           //display the stored node//

int main()
 {
	int choice;
	char ch;
	
	node* head =NULL;               
	node* tail =NULL;              
	
	do{
			
			printf("Store data at the end of NODE :----\n");
			printf("Display the Linked List :----\n");
			
			
		printf("\nEnter your choice :");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1:
			{
				if(tail ==NULL)
      				{
      					tail = store_data(tail);
      					head = tail;
      				}
        			else
        			{
        				tail = store_data(tail);
        			}        
				break;
			}	
			
			case 2:
			{
			 	if(head == NULL)
        			{
        	 			printf("Linked List is Empty...\n");
        	 		}
        	 		else
        	 		{
               				display_data(head); 
        			}
				break;
			}	
			
			default:
			{
				printf("Invalid Choice..");
				break;
			}
		}	
			
	printf("Do you want to continue...Y/N\n");
	scanf("%c",&ch);
	scanf("%c",&ch);
			
	}while(ch == 'y' || ch == 'Y');
	return 0;
 }



node* create_new_node()
  {
	node* new_node =(node*)malloc(sizeof(node));
	if(new_node != NULL)
	{
		printf("\nEnter the data: ");
		scanf("%d", &new_node->data);
		new_node->next=NULL;
	}
	else
	{
		printf("\n System failed to allocate new memoery...\n");   
	}
	return new_node;
  }
  
node* store_data(node* n)
  {
	if( n == NULL)
	{
		n= create_new_node();
		return n;
	}
	else
	{
		node* new_node = create_new_node();
		new_node->next = n;
		return new_node;
  	} 
  }
  
void display_data(node* n)
  {
		printf("Linked List Elements are :\n");
		while(n->next !=NULL)
		{
			printf("==> %d\n",n->data);
			n = n->next;
		}  
		printf("==> %d\n",n->data);
  }