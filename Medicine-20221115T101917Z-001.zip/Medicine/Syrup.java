package com.cdac;

public class Syrup  extends Tablet
{
	public void displayLabel()
	{
		System.out.println("Store syrups in cool and dry place");
	}

}
