package com.cdac;

public class Ointment extends Tablet
{
	public void displayLabel()
	{
		System.out.println("Ointment should be for external use only");
	}

}
