package com.cdac;

public class Tablet extends Medicine
{
	public void displayLabel()
	{
		System.out.println("Store Tablets in cool and dry place");
	}
		
}
