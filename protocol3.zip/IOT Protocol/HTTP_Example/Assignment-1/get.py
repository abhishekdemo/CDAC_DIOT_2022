# Program to perform simple GET request to HTTP server
import requests
import json

# HOST = "http://localhost:"
# PORT = "3000"
# HTML_RES_PATH = "/"
# JSON_RES_PATH = "/json"
# DB_PATH = "/value"

URL = "http://localhost:3000/json/value"
# Make HTTP GET Request to Server
response = requests.get(URL)


# Printing the JSON response with inbuilt encoder
print(response.json())
print(response.status_code)