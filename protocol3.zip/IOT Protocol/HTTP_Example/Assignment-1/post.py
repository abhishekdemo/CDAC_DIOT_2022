# Program to perform simple GET request to HTTP server
import requests
import json

HOST = "http://localhost:"
PORT = "3000"
PATH = "sensor/value"
# URL= "http://localhost:3000/json/value"
REQUEST_BODY = {
    "UNIQUE ID": "101",
    "TYPE": "IOT",
    "VALUE": 93
}

response = requests.post(HOST+PORT+PATH, REQUEST_BODY)

print(response.json())