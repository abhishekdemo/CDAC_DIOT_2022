const axios = require('axios')

// Program to make a simple GET request and parse the Response Body
const HOST = "https://api.thingspeak.com:";
const PORT = "443"
const HTML_RES_PATH = "/"
const JSON_RES_PATH = '/json'
const DB_PATH = '/update.json'

const URL= "https://api.thingspeak.com/update?api_key=E649BO46UTKL9NWK&field1=43.4&field2=75";

// Make a GET request to Server
axios.get(URL)
    .then((response)=>{
        const RESPONSE_BODY  = JSON.stringify(response.data, null,2);
        console.log("Data: "+RESPONSE_BODY+". Response Code: "+ response.status)
    }).catch(error=>{
        console.log(error);
    })