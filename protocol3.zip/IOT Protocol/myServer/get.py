# Program to perform simple GET request to HTTP server
import requests
import json

HOST = "https://api.thingspeak.com:"
PORT = "443"
CHANNEL_ID ="1979353"
JSON_RES_PATH = "/channels/"+CHANNEL_ID+ "/feeds.csv"
QUERY_STRING="?api_key=E649BO46UTKL9NWK";
# DB_PATH = "/sensor/value"

# Make HTTP GET Request to Server
response = requests.get(HOST + PORT + JSON_RES_PATH+QUERY_STRING)


# Printing the JSON response with inbuilt encoder
print(response.text)
print(response.status_code)