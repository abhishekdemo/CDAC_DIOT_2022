# Program to perform simple GET request to HTTP server
import requests
import json

HOST = "https://api.thingspeak.com:"
PORT = "443"
CHANNEL_ID ="1979353"
PATH = "/channels/"+CHANNEL_ID+ "/feeds.csv"
QUERY_STRING="?api_key=E649BO46UTKL9NWK";
REQUEST_BODY = {
    "sensor": "humidity",
    "value": 44,
    "unit": "F"
}

response = requests.post(HOST + PORT + PATH+ QUERY_STRING, REQUEST_BODY)

print(response.text)