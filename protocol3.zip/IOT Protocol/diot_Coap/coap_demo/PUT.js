// A Program to send a PUT Request
const coap = require('coap');

const req = coap.request({
    host:"127.0.0.1",
    port: 5683,
    pathname: "/diot",
    method: 'PUT'
})
req.setOption("Content-Format","application/json")
req.setOption("Block1",Buffer.alloc(0x2))
const payload ="{'name':'Hello'}"
req.write(payload)

  req.on('response', (res) => {
    console.log(res.code) //2.xx,4.xx
    res.pipe(process.stdout)
    res.on('end', () => {
      process.exit(0)
    })
  })

  req.end()