import java.util.*;
  
public class Q1 
{
    
	public static double VolumeOfSphere (double radius) 
	{
		double Volume = (4.0 / 3) * Math.PI * radius * radius * radius;
		return Volume;
	}
	
	public static double SurfaceAreaOfSphere (double radius) 
	{
		double surfacearea =  4 * Math.PI * radius * radius;
		return surfacearea;
	}
	
    public static void main (String[] args)
    {
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter the radius of the sphere: ");
       double radius=sc.nextDouble();
       double surface_area = SurfaceAreaOfSphere(radius);
       double volume = VolumeOfSphere(radius);
       System.out.println("The surface area of the sphere = "+surface_area); 
       System.out.println("The volume of sphere = "+volume);
       
    }
}




