//program to understand JSON parsing

let JSON_string= '{"name":"bhushan"}'
let JSON2_string= "{\"name\":\"bhushan\"}"
// let JSON1_string= '{name:bhushan}'

let obj= JSON.parse(JSON_string);

console.log("Type of obj:" + typeof(obj));
console.log("Type of JSON Obj: "+typeof(JSON_string));