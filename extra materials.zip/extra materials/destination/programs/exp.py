def my_sum(a,b):
    c=a+b
    return c
print(my_sum(1,2))
print(my_sum(1,"a"))

def my_sum_exception_handler(a,b):
    try:
        c=a+b
        except Exception:
            print("some error ")