#include<stdio.h>
#include<malloc.h>
int** Allocate_memmory_matrix(int** m,int r,int c)
{
//allocate a memmory for first 2D-matrix
m=(int*)malloc(sizeof(int*) * r);
for(int i=0;i,r;i++)
{
m[i]=(int*)malloc(sizeof(int) * c);
}
return m;
}
