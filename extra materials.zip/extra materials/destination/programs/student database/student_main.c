#include"student_database.h"
#include<stdio.h>

int main()
{
int choice;
char ch;
//declare array of students
student s[5];

do
{
printf("\n********MENU*******\n");
printf("\n1.accept student details\n");
printf("\n2.print all students details by perticular joiningyear\n");
printf("\n3.print all students details by perticular roll no\n");
printf("\n enter your choice\n");
scanf("%d",&choice);
switch(choice)
{
case 1:
accept_student_details(s);
break;
case 2:
print_all_student_by perticular_joining_year(s);
break;
case 3:
print_all_student_by perticular_roll_no(s);

break;
default:
printf("\nivalid choice\n");
}
printf("do you want to continue....Y/N:")
scanf("%c",ch);
scanf("%c",ch);
}
while (ch=='y' || ch=='Y');
return 0;
}



