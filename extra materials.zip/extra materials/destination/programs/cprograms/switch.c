/*
decision using switch- add,sub,mul and div
*/
#include<stdio.h>
int main()
{
int inum1,inum2, choice:
printf("\nenter the inum1:);
scanf_s("%d",&inum1:");
printf("\nenter the inum2:);
scanf_s("%d",&inum2:");
printf("\n********aruthmatic operation:********");
printf(\n1.addition\n2.substraction\n3.multiplication\n4.division\n");
printf("\n enter your choice);
scanf s("%d",&choice);
switch (choice)
{
    	 case1:
     	{
    	 int res+inum1+inum2;
     	printf("\naddition of %d and %d is %d \n"inum1,inum2,res);
    	 }

    	 case2:
 	{
	int res+inum1-inum2;
 	printf("\nsubsraction of %d and %d is %d \n"inum1,inum2,res);
	}
 	case3:
		{
	int res+inum1*inum2;
	printf("\nmultiplication of %d and %d is %d \n"inum1,inum2,res);
	}
	case4:
	{
	int res+inum1/inum2;
	printf("\ndivision of %d and %d is %d \n"inum1,inum2,res);
	}
	break;
default:
{
printf("invalid choice");
return 0

