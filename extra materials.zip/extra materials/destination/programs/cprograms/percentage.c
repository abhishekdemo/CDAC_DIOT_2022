#include<stdio.h>
int main()
{
int inum1,inum2,inum3,inum4,inum5;
printf("enter the marks of five subject:\n");
scanf("%d,%d,%d,%d,%d" & inum1,inum2,inum2,inum3,inum4,inum5);
percentage=(total/500)*100
printf("percentage=%d", percentage);
return 0;
}
