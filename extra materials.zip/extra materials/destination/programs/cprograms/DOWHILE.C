/*write ac program to use do while effectively into your code */
#include<stdio.h>
int main()
{
char ch;
do {
printf("\n do you want to continue....\n");
scanf("%c",&ch,1);
}while(ch=='y' ||ch=='Y');
}
