#include <stdio.h>

int main()
{
    int eng, phy, chem, math, comp; 
    int percentage,total;

    /* Input marks of all five subjects */
    printf("Enter marks of five subjects: \n");
    scanf("%d%d%d%d%d", &eng, &phy, &chem, &math, &comp);

    /* Calculate total, average and percentage */
    total=eng+phy+chem+math+comp;
    percentage = (total / 500.0) * 100;

    /* Print all results */
    printf("\nPercentage = %d", percentage);
    printf("\n");
    return 0;
}
