#include<stdio.h>
int main(){
char ch;
do{
int inum1,inum2,choice,res;
printf("enter the inum1:");
