/* write a c program to check given number is prime number or not for loop.*/

#include<stdio.h>
int main()
{
int inum,i;

for(inum=2;i<inum;i++)
{
if(inum % i ==0)
break;
}
if(i==inum)
{
printf("\n%d is prime no\n",inum);
}
else
{
printf("\n%d is not prime no\n",inum);
scanf("%c",&ch,1);
scanf("%c",&ch,1);
}
while(ch=='y' || ch=='Y');
return o;
}
