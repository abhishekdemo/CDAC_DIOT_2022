#include<stdio.h>
int main();
{
int first,second,third;
printf("enter first number");
