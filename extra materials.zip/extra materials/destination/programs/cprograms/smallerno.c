#include<studio.h>
int main()
{
int inum1,inum2,inum3;
printf("enter the first number":);
scanf("%d,& inum1);
printf("enter the second number":);
scanf("%d,& inum2);
printf("enter the third number":);
scanf("%d,& inum3);

if(inum1>inum2)
{
printf("%d is positive\n",inum);
}
else
{
printf("%d is Negative\n",inum);
}
