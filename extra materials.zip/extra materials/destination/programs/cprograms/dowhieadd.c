#include <stdio.h>
int main()
{
char ch;
do
{
int inum1,inum2,choice,res;
printf("enter the inum:");
scanf_s("%d",&inum1);
printf("enter the inum:");
scanf_s("%d",&inum1);
printf("\n********arithmatic operation\n");
printf("\n1.addition\n2.sub\n3.mult\n4.div\n");
scanf_s("%d",&choice:);
switch(choice);
{
case 1;
int res=inum1+inum2;
printf("\n addition of %d and %d is\n",inum1,inum2,res);
}
break;
case 1;
int res=inum1+inum2;
printf("\n addition of %d and %d is\n",inum1,inum2,res);
}
break;
case 2;
int res=inum1-inum2;
printf("\n sub of %d and %d is\n",inum1,inum2,res);
}
break;
case 3;
int res=inum1*inum2;
printf("\n mult of %d and %d is\n",inum1,inum2,res);
}
break;
case 4;
int res=inum1/inum2;
printf("\n div of %d and %d is\n",inum1,inum2,res);
}
break;
default:
{
printf("invalid choice");
}
}
printf("\n do you want continue...\n");
scanf("%c,&ch);
}
while(ch=='y' ||ch=='Y');
retuen 0;
}

return 0;
}
