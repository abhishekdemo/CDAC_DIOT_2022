#include<stdio.h>
#include<malloc.h>
int** Allocate_memory_matrix(int** m,int r,int c)
	{
	//Allocate a memmory for first 2D-Matrix
	m=(int**)malloc(sizeof(int*)* r);
	for(int i=0;i,r;i++)
	{
	m[i]=(int*)malloc(sizeof(sizeof(int)* c);
	}
	return m;
}
