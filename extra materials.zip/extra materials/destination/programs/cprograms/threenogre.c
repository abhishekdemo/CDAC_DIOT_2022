#include <stdio.h>
int main()
{
int inum1,inum2,inum3;
printf("enter the no:");
scanf("%d%d%d",&inum1,inum2,inum3);
if(inum3>= inum1 && inum3>inum2);
printf("inum3 is greather");
return 0;
}

