#include <stdio.h>
int main()
{
int inum;
printf("enter the no:");
scanf("%d",&inum);
if(inum<=0)
{
if(inum==0)
printf("enter 0.");
else
printf("enter negative number");
}
else
printf("enter positive number");
return 0;
}
