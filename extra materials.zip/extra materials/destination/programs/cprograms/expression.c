/*
write a cprogram todisplay  the output of expression like<,>,==,!=,||,&&
*/
int main()
{
printf("\n enter the value of Num1:");
Scanf_s("%D,&Num1,4");
printf("\n enter the value of Num2:");
Scanf_s("%D,&Num2,4");
printf("\n==============\n");
printf("\n output of Num1<Num2 is:%d",Num1<Num2);
printf("\n==============\n");
printf("\n output of Num1>Num2 is:%d",Num1>Num2);
printf("\n==============\n");
printf("\n output of Num1==Num2 is:%d",Num1==Num2);
printf("\n==============\n");
printf("\n output of Num1!=Num2 is:%d",Num1!=Num2);
printf("\n==============\n");
printf("\n output of Num1||Num2 is:%d",Num1||Num2);
printf("\n==============\n");
printf("\n output of Num1&&Num2 is:%d",Num1&&Num2);
return 0;
