#include"matrix_operation.h"
#include<stdio.h>
int main()
{
//declare double pointer toallocate a memory for 2d array
int** m1=NULL;
int** m2=null;
int row,col;
int chice;
char ch;
do
{
	printf("\n*******MENU*******|n");
	Printf("1.Allocate memmory\n");
	Printf("1.accept 2dmatrix\n");
	printf("3.Display Matrix\n");
	PRINTF("4.Addition of matrix\n");
	printf("please enter your choice:");
	scanf(%d,&choice);
	switch(choice)
	{
	case 1:
	{
	m1=allocate_memmory_matrix(m1,row,col);
	m2=allocate_memmory_matrix(m2,row,col);
	}
	break;
	case 2:
	{
	if(m1 !=NULL && m2 !=NULL)
	{
	accept_matrix(m1,row,col);	
	accept_matrix(m2,row,col);
	}
	else
	{
	if(m1==NULL)
	{
	m1=allocate_memmory_matrix(m1,row,col);
	accept_matrix(m1,row,col);
	}
	if(m2==NULL)
	{
	m2=allocate_memmory_matrix(m2,row,col);
	accept_matrix(m2,row,col);
	break;
	}
	}
	case 3:
	{
	display_matrix(m1,row,col);
	display_matrix(m2,row,col);
	}
	break;
	case 4:
	{
	if(m1 !=NULL && m2 !+NULL)
	{
	int** temp+Addition_matrix(m1,row,col);
	}
	else if(m1==NULL || m2==NULL)
	{
	if(m1==null)
	m1=allocate_memmory-matrix(m1,row,col);
	if(m2==null)
	m2=allocate_memmory-matrix(m2,row,col);
	int**temp=addition_matrix(m1,m2,row,col);
	

}
}

	break;
	default:
	}
	printf("\n do you want to continue.....\n");
	scanf("%c",&ch,1);
	scanf("c),&ch);
