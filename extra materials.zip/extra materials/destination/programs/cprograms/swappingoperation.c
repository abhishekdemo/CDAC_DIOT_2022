#include<stdio.h>
int main()
{
int first,second,third;
printf("enter first number");
scanf("%d",&first);
printf("enter second number");
scanf("%d",&second);
third=first;
first=second;
second=third;
printf("\nafter swapping first number=%d\n",first);
printf("\nafter swapping second number=%d\n",second);
return 0;
}

