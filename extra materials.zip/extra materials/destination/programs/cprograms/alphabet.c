/*write c programs  to print alphabetsfrom a to z*/

#include <stdio.h>
int main()
{
    char ch;
    printf("Alphabets from a - z are: \n");
    for(ch='a'; ch<='z'; ch++)
    {
     
        printf("%c\t", ch);
    }
    return 0;
}
