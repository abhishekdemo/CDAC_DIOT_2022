#pragma once
struct book
{
int page_no;
char name[15];
float price;
};
//create short name of structure(alias)
typedef struct book book;

//function declaration
void accept_book_details(book* b);
void display_book_details(book* b);
