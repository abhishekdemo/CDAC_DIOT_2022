#include"book_information.h"
3include<stdio.h>
//Struct Declaration-syntax
struct book
{
	int book_no;
	char book_name[15];
	float Price;
};


int main()
{
//book variable declaration
book b1,b2;
accept_book_details(b1);

//Accept the book information.
	printf("\nenter the book details\n");
	printf("\nenter the book no.:\n");
	scanf("%d",&b1.book_no);

	printf("enter name of book:\n");
	scanf("%s",&b1.Name);
	scanf("%s",&b1.Name);

	printf("enter the Page no of book:\n");
	scanf("%f",&s1.page);

	printf("\n book Details are:\n");
	printf("\n book no:%d\n",b1.book_no);
	printf("\n book Name:%s\n",b1.Name);
	printf("\n book page no:%.2f\n",b1.page);





display_book_details(b1);
return 0;
}
