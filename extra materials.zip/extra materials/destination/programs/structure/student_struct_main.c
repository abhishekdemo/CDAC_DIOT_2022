/*
write a c program to accept student information like student_rollno,student_name,student_percentage etc. and  Display on console.
*/
#include<stdio.h>

//Struct Declaration-syntax
struct student
{
	int Roll_no;
	char Name[15];
	float Percentage;
};
int main()
{
//declare structure variable -syntax
	struct student s1,s2,s3;

	//Accept the student information.
	printf("\nenter the student details\n");
	printf("\nenter the roll no.:\n");
	scanf("%d",&s1.Roll_no);

	printf("enter name of student:\n");
	scanf("%s",&s1.Name);
	scanf("%s",&s1.Name);

	printf("enter the Percentage of the student:\n");
	scanf("%f",&s1.Percentage);

	printf("\n Student Details are:\n");
	printf("\n Roll no:%d\n",s1.Roll_no);
	printf("\n Student Name:%s\n",s1.Name);
	printf("\n Student Percentage:%.2f\n",s1.Percentage);
	//Q: Assing the data of s1 to s2 variable member by member 
	//memberwise copy
	s2.Roll_no=s1.Roll_no;
	strcpy(s2.Name,s1.Name);
	s2.Percentage=s1.Percentage;
	printf("\n===================\n");
	printf("\nStudent2 details are :\n");
	printf("Roll no :%d\n",s2.Roll_no);
	printf("Student Name :%s\n",s2.Name);
	printf("Student Percentage :%.2f\n",s2.Percentage);

	s3.Roll_no=s2.Roll_no;
	strcpy(s3.Name,s2.Name);
	s3.Percentage=s2.Percentage;
	printf("\n===================\n");
	printf("\nStudent3 details are :\n");
	printf("Roll no :%d\n",s3.Roll_no);
	printf("Student Name :%s\n",s3.Name);
	printf("Student Percentage :%.2f\n",s3.Percentage);


 	return 0;
}
