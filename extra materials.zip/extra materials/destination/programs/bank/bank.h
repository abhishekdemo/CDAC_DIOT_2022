#pragma once

struct bank
{
int account no;
char name[15];
int balance in account[15];




};
//create short name of structure(alias)
typedef struct bank bank;

//function declaration
void accept_bank_details(bank* b);
void display_bank_details(bank* b);
