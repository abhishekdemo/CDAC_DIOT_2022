//util.format(....)
//util.isArray([])-----true
//util.isArray({})-----false
//util.isDate(new Date())-----true
//util.isDate(Date())-----false