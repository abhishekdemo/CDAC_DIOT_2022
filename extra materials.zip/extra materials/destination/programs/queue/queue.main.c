#include<stdio.h>
#include"queue.h"

int main()
{
int choice();
char ch;
QUEUE Q;
Q.Front=Q.Rear =-1;



do
{
	printf("\n========MENU========\n");
printf("1.Enqueue the element in queue....!\n");
printf("2.Dequeue the element in queue....!\n");


printf("\nplease enter your choice\n");

scanf("%d",&choice);

switch(choice)
{
case 1:

 enqueue(&q);
 break;

case 2:
{
 dequeue(&q);
break;
default:
break;
}
while
{cha


