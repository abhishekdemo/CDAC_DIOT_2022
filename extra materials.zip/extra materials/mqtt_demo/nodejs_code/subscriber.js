// Program to publish data to Broker on TOPIC
const mqtt = require('mqtt');

const HOST = 'mqtt://localhost:';
const PORT = '1883';

const subscriber = mqtt.connect(HOST + PORT);

// MQTT Topic to Publish data to
const TOPIC = 'cdac/diot';

// Event to Check BROKER connection
subscriber.on('connect',()=>{
    
    console.log("Connected to MQTT Broker!");

    // Publish the data
    subscriber.subscribe(TOPIC, (err, granted)=>{
        if(!err){
            console.log(`Granted. Topic: ${granted.topic}, QoS: ${granted.qos}`);
        }
    });
})


