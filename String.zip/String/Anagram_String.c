/*
	Write a C program to accept Two strings from user amd check the entered strings are ANAGRAM strings or not
*/
