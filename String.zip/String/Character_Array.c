/*  
    Write a C program to understand the character array...!!
*/

#include<stdio.h>
int main()
{
	//Initialization of character array
	//char Name[]={'D','I','O','T','\0'};
	char Name[]="DIOT";
	int i=0;
	/*
	while(Name[i] !='\0')
	{
	  printf("%c",Name[i]);
	  i++;
	}*/
	printf("%s",Name);
	printf("\n");
	return 0;	


}
