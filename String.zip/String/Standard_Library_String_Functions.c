/*
  Write a C Program for string and use standard library string functions
  like strlen,strcpy,strcat,strrev.
*/

#include<stdio.h>
#include<string.h>
int main()
{
	char Name[20];

	printf("Enter the name:");
	scanf("%s",Name);

	int Len=strlen(Name);
	printf("String length of %s is %d\n",Name,Len);
	printf("\n----------------\n");

	char Temp[20];
	strcpy(Temp,Name);
	printf("After copy:%s\n",Temp);
	printf("\n----------------\n");

	char fName[25]="Yogesh";
	char lName[]="Mehetre";

	printf("Before concatnate:%s\n",fName);
	printf("Before concatnate:%s\n",lName);

	strcat(fName,lName);
	printf("\n------------\n");

	printf("After concatnate:%s\n",fName);
	
	printf("\n------------\n");

	return 0;
	
}
