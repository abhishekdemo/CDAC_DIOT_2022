#include<stdio.h>
#include<string.h>


int main()
{
	char Original[20];
	printf("\n Enter the string:");
	scanf("%s",Original);

	char temp[20];
	strcpy(temp,Original);
	strsep(temp);
	int res=strcmp(temp,Original);

	if(res==0)
	{
		printf("\nString is palindrome\n");
}else
{
		printf("\nString is not palindrome\n");
}
	return 0;
}
