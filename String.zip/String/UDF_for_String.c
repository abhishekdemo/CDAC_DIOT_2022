/*
	Write a C program to implement user define functions for string operations.
*/

#include<stdio.h>
//Function Declaration
int Strlen(char *str);
void Strcpy(char *target,char *source);
void Strrev(char *str);
void Sort(char *str);

int main()
{
	char str[20];
	printf("\nEnter the string:");
	scanf("%s",str);

	int Len=Strlen(str);
	printf("String length of %s is:%d",str,Len);

	printf("\n-----------------\n");

	char Newstr[20];

	Strcpy(Newstr,str);
	printf("After copy:%s\n",Newstr);

	Strrev(str);
	printf("After reverse:%s\n",str);

	Sort(str);
	printf("After sorting:%s\n",str);
	
		return 0;
}

//Function Defination
int Strlen(char *str)
{
	int len=0;
	while(str[len] !='\0')
	{
		len++;
}
	return len;
}
void Strcpy(char *target,char *source)
{
	int i=0;
	while (source[i] !='\0')
{
	target[i]=source[i];
	i++;
}
	target[i]='\0';
}
void Strrev(char *str)
{
	int Len=Strlen(str);
	char temp;
	int i=0;
	while(i !=Strlen(str)/2)
{
	temp=str[i];
	str[i]=str[Len-1];
	str[Len-1]=temp;
	i++;
	Len--;
}
}
void BSort(char *str)
{
	int i=0,j=0;
	for(i=0;i<Strlen(str);i++)
{
	for(j=i;j<Strlen(str)-1;j++)
{
	if(str[j]<str[j+1])
{
	char ch;
	ch=str[j];
	str[j]=str[j+1];
	str[j+1]=ch;
	
}
}

}
}
