#include<stdio.h>
#include<sys/types.h>
#include <stdio.h>       //fgets & printf
#include <sys/types.h>  //mkfifo
#include <sys/stat.h>  //mkfifo
#include <unistd.h>   //write
#include <stdlib.h>                 //system
#include <fcntl.h>                 //open
#include <string.h>               //strlen
int main()
{
    fork();
    
    printf("there is child");
}