"""
        Ref:https://superfastpython.com/thraeding-in-python/
"""

from time import sleep

from threading import Thread

def do_something():

    #sleep(2)
    for i in range (40):
        print(" i am from diot batch 2022")

def do_something1():

    #sleep(2)
            for i in range (100):
                 print(" i am from diot batch 2023")
     
     

     
#creat a thread


t1 =Thread(target=do_something)  #syntax of thread in python
t2 =Thread(target=do_something1)
#run the thread

t1.start()
t1.join()
t2.start()
t2.join()

print("passion")



