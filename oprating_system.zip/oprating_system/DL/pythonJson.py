import json

info={
    "Institute":"CDAC",
    "year":2022,
    "student":True,
    "classes":("DIOT","DAC"),
    "passout":None

}

#converting python object into JSON object
myJSONString=json.dumps(info)

#converts to python object
myJson=json.loads(myJSONString)

#JSON string
print(type(myJson))