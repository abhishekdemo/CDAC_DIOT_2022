#include<stdio.h>
#include<basic-header.h>
int main()
{
    int c=add(10,20);
    printf("Addition is  %d\n",c);
    return (0);
}