#include<stdio.h>
#include<sys/types.h>
#include<stdlib.h>
#include<unistd.h>
long long int final_value=0; //shared variable
int main()
{
 pid_t pid;
 int count1,count2;
 pid=fork();
 if(pid==0)
 {
    for(count1=0;count1<=100;count1++)
    {
        final_value=final_value-1;
        printf("The final value via parent=%lld\t",final_value);
    }
 }
else if (pid>0)
{
     for(count2=0;count2<=50;count2++)
    {
        final_value=final_value+1;
        printf("The final value via child=%lld\t",final_value);
    }

}
else{

        printf("Child process is not created\n");
}
return 0;
}