#include<stdio.h>
#include"python1.h"
#include"header.h"
#include<stdlib.h>
#include<unistd.h>
//int main(){

  //  void python1()
  int main()
  {
    runpython();
    cpcration();
    return 0;
  }
