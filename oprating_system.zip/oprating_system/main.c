#include<stdio.h>
#include"sum.h"
#include"mul.h"
int main()
{
    int a,b;
    printf("Learning how to make file\n");
    printf("Enter first number\n");
    scanf("%d",&a);
    printf("Enter second number\n");
    scanf("%d",&b);
    int res1=sum(a,b);
    int res2=mul(a,b);
    printf("%d + %d=%d\n",a,b,res1);
    printf("%d * %d=%d\n",a,b,res2);
    return 0;
}


