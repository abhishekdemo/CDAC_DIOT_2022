int div(int a,int b)
{
    return a-b;
}