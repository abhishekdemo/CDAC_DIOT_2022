#include<stdio.h>
#include "basic-header.h"

int main()
{
    int number1,number2,choice,res;
    printf("entr the first number\n");
    scanf("%d",&number1);
    printf("enter the second number");
    scanf("%d",&number2);

    printf("Enter the choice");

    printf("1.add");
     printf("2.div");
      printf("3.sub");
       printf("4.mul");
       scanf("%d",&choice);
       switch(choice)
       {
            case 1:
            res=add(number1,number2);
            printf("%d%d%d",number1,number2,res);
            break;

            case 2:
            res=sub(number1,number2);
            printf("%d+%d=%d",number1,number2,res);
            break;

            case 3:
            res=div(number1,number2);
            printf("%d/%d=%d",number1,number2,res);
            break;

            case 4:
            res=mul(number1,number2);
            printf("%d*%d=%d",number1,number2,res);
            break;
            default:
            printf("error choice\n");
       }

}