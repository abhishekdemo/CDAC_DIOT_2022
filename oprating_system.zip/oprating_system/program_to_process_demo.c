#include<stdio.h>
#include<unistd.h> 
#include <time.h> //man 3 sleep

/*int main(int argc,char *argv[])
{
   for(int index=0;index<20;index++)
    {
        printf("Value of index=%d\n",index);
        sleep(4);
        printf("Value of index=%d\n",index);
        sleep(4);


    } */

    int main()
    {
        clock_t t;
        t = clock();
        for(int i=0;i<=8;i++)
        {
           // fork();
        printf("Before fork\n");
        //fork();
        }
        t = clock() - t;
        double time_taken = ((double)t)/CLOCKS_PER_SEC;
        printf("Total %f seconds took to execute the program \n", time_taken);
        //fork();
       // fork()
       // fork();
       
       
       for(int j=0;j<=8;j++)
        {
            //fork();
        printf("After fork\n");
        //sleep(2);
        //printf("Mohsin\n");
        }
        t = clock() - t;
        double time_taken2 = ((double)t)/CLOCKS_PER_SEC;
        printf("Total %f seconds took to execute the program \n", time_taken);
       // printf("After fork2222\n");
        
    
    return 0;  



/*int main()
{
    /*pid_t ret;
    ret=fork();
    if(ret==0)
    {
        printf("child process is created\n");
        printf("%d\n",ret);
    }
    else if(ret>0)
    {
        printf("parent process block\n");
        printf("%d\n",ret);
    }
    else
    {
        perror("child is not created\n");
        printf("%d\n",ret);
    }*/



    
}
