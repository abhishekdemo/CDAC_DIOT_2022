#include <stdio.h>
#include <sys/types.h>
//#include <stdlib.h>
#include <unistd.h>
int main()
{
    void cpcreation()
    {
        printf("running \n");
    }

    pid_y pid ;
    pid =fork();

    if(pid>0)
    {
        printf("i am in parent");
    }

    else if(pid==0)
    {
        printf("i am in child class\n");
    }
   
   /* printf("Hii....It's parent class\n");
    fork();
    printf("Hii....It's child class\n");*/

    return 0;
}
