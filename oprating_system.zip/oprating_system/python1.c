#include<stdio.h>
#include<sys/types.h>
#include<stdlib.h>
 #include <unistd.h>



#include"python1.h"

int main()
{
    void runpython1()
    {
    pid_t ret;
    ret = fork();
    {

            system(" python Helloworld.py");
    }
    }
    

   
    return 0;
}