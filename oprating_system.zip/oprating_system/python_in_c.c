#include<stdio.h>
#include<sys/types.h>
#include<stdlib.h>
#include <unistd.h>


int main()
{
    pid_t ret;
    ret=fork();
    if(ret==0)
    {
        system("enter the python code");
    }

    else if(ret>0)
    {

        system("enter the node.js code");
    }
    else{
        perror("child is not created");
    }

    return 0;

}