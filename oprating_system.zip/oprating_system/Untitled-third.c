#include<stdio.h>
#include<stdlib.h>
//#include<sys/types.h>
#include<sys/types.h>

#include<unistd.h>
int main()
{
pid_t fork_ret_val;

pid_t pid;
fork_ret_val=fork();

if(fork_ret_val==0)
{
    printf("childprocess %d",getpid());
    printf("child process%d",getppid());
}


else if(fork_ret_val>0)
{
    sleep(3);
    printf("fork ret val=%d",fork_ret_val);
    printf("child proces %d",getpid());
    printf("parent process %d",getppid());
}
else
{
    printf("this is no choice");
    exit(0);
}
}