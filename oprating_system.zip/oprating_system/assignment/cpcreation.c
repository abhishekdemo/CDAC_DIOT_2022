#include <stdio.h>
#include <sys/types.h>
//#include <stdlib.h>
#include <unistd.h>
void cpcreation()
    {
        printf("running \n");
    

    pid_t pid ;
    pid =fork();

    if(pid>0)
    {
        printf("i am in parent");
    }

    else if(pid==0)
    {
        printf("i am in child class\n");
    }
   
   /* printf("Hii....It's parent class\n");
    fork();
    printf("Hii....It's child class\n");*/
    }