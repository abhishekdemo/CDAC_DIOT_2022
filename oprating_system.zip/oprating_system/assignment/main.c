#include<stdio.h>
#include"header.h"
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
//int main(){

  //  void python1()
  int main()
  {
    runpython();
    cpcreation();
    return 0;
  }