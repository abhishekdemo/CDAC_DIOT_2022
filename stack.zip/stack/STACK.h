//Structure for STACK data structure
#include<stdio.h>
#include<stdbool.h>

#ifndef STACK_H
#define STACK_H

	struct STACK
{
	int Top;
	int arr[5];
};
#endif

//Create a short name for structure

	typedef struct STACK STACK;

//STACK functions

	bool Stack_Overflow(STACK* s);
	bool Stack_Underflow(STACK* s);
	void Push(STACK* s);
	void Pop(STACK* s);
	void peek(STACK* s);
