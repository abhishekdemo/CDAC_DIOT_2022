struct Date
{
	int Day,Month,Year;
}
