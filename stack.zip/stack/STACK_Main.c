#include"Stack.h"
#include<stdio.h>
#include<stdbool.h>


int main()
{
	char ch;
	STACK S1;
	S1.top= -1;


	do
{
    printf("\n*********MENU**********\n");
	printf("\n Do you want to continue....Y/N");
	

}while(ch == 'y' || ch == 'Y');
}
