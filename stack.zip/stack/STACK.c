#include"Stack.h"
#include<stdio.h>
#include<stdbool.h>

//Stack functions
	bool Stack_Overflow(STACK* s);
{
	int stack_size=sizeof(s->arr) / sizeof(int);
	//printf("Total elements size of stack is:%d\n",stack_size);

	if(s->Top==stack_size-1)
	return true;
	else
	return false;
}
	bool Stack_Underflow(STACK* s);
{
	if(s->Top==-1)
	return true;
	else
	return false;
}
	void Push(STACK* s);
{
	if(!Stack_Overflow(s))
{
	printf("\nEnter the value to push into stack:\n");
	scanf("%d",&s->arr[++s->Top]);
}
	else
{
	printf("\n Stack is full....\n");
}
}
	void Pop(STACK* s);
{
	if(!Stack_Underflow(s))
{
	printf("\nPoped value from Stack is:%d\n",s->arr[s->Top--]);

}
	else
{
	printf("\n Stack is empty....\n");
}
}
	void peek(STACK* s);
{
	if(!Stack_Underflow(s))
{
	printf("\nPoped value from Stack is:%d\n",s->arr[s->Top]);
	
}
	else
{
	printf("\n Stack is empty....\n");
}
}
