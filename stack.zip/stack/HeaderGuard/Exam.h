#include"Global.h"

struct Exam
{
	int Roll_no;
	char Name[20];
	Date DOB;
};
