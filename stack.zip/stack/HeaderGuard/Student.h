#include"Global.h"

struct Student
{
	int Roll_no;
	char Name[20];
	Date DOB;
};
