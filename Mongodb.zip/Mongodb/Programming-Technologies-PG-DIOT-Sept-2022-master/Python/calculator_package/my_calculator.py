from my_artihmatic_operation import my_add,my_substract
#import my_artihmatic_operation

def my_calculator_operation(a,b):
    print("my_calculator_operation() was invoked")
    print("Addition of the provided number is ", my_add(a,b))
    print("Addition of the provided number is ", my_substract(a,b))
    #print("Addition of the provided number is ", my_artihmatic_operation.my_add(a,b))
    #print("Addition of the provided number is ", my_artihmatic_operation.my_substract(a,b))

#execute the function to all operations on the provided input 
my_calculator_operation(3,4)


