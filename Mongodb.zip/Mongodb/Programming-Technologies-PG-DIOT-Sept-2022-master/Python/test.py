import requests

url="https://www.kaggle.com/louise2001/quantum-physics-articles-on-arxiv-1994-to-2009/download"

r = requests.get(url)
print(r.headers)