read -p "Enter your first name" fname
read -p "Enter your last name" lname

echo "Your name is $fname $lname"pwd
