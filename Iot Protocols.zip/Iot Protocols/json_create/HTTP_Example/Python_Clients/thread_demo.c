#include<stdio.h>
#include<pthread.h>
#include<unistd.h>
void *msg(void *ptr)
{
    printf("Today is wesdnesday\n");
      printf("routine for thread 1\n");
      sleep(60);
}

thread routine
{
    pthread_t thread1,thread2;
    printf("before thread\n");
    int ret1 = pthread_create(&thread1,NULL,msg,NULL);
    int ret2 = pthread_create(&thread2,NULL,quote_of_the_day,NULL);

      pthread_join(thread1,NULL);
      pthread_join(thread2,NULL);

}


