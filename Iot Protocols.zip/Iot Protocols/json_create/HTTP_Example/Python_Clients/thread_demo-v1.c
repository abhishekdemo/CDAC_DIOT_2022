#include<stdio.h>
#include<pthread.h>
#include<wait.h>
void *msg(void *ptr)
{
    printf("Today is wesdnesday\n");
        sleep(60);
      printf("routine for thread 1\n");
}
/*
thread routine II
*/
void *quote_of_the_day(void *ptr)
{
    printf("success is npt an event; it will happen gradualy\n");
    printf("Thread -->2\n");
}
void main()
{
    pthread_t thread1,thread2;

    printf("before thread\n");
    int ret1 = pthread_create(&thread1,NULL,msg,NULL);                                                                                                                                                                                                                                                         
























}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
    pthread_join(thread1,NULL);
    int ret2 = pthread_create(&thread2,NULL,quote_of_the_day,NULL);

      //pthread_join(thread1,NULL);
      pthread_join(thread2,NULL);

}


