# Program to perform simple GET request to HTTP server
import requests
import json

HOST = "https://api.thingspeak.com:"
PORT = "443"

#JSON_RES_PATH = "/json"
#DB_PATH = "/sensor/"

CHANNEL_ID = "1979352"
JSON_RES_PATH = "/channels/"+CHANNEL_ID+".csv"
QUERY_STRING= "PLZITDJNZ90FP4WP"
# Make HTTP GET Request to Server
response = requests.get(HOST + PORT + JSON_RES_PATH+QUERY_STRING)


# Printing the JSON response with inbuilt encoder
print(response.text)
print(response.status_code)
