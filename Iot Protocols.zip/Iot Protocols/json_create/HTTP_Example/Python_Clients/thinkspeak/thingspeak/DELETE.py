# Program to perform simple GET request to HTTP server
import requests
import json

HOST = "https://api.thingspeak.com:"
PORT = "443"
#PATH = "/sensor/value"
DELETE_INDEX = ""
CHANNEL_ID="1979352"


key="DKKHS2H2K7TYDRIO"
PATH="/channels/"+CHANNEL_ID+".csv?api_key="+key
response = requests.delete(HOST + PORT + PATH + DELETE_INDEX)

print(response.json())