//ps -T -p <pid>
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

//Thread routine --> function
void *routine1(void *msg)
{
  printf("I am fron routine 1\n");   
  sleep(40);
}
int main(int argc, char* argv[])
{
pthread_t t1;
//Create a Thread
pthread_create(&t1,NULL,routine1,NULL);
system("python3 hi.py");
	/*
	pthread_join will block the calling thread i.e. main thread
	to complete the execution of thread which is passed as a first arugument
	Note:
	if pthread_join will not be used : It may happen that main thread has complete
     its execution and some statement doesn't
	yield the results e.g. printf takes time to send buffer data to console
	*/
printf("I am outside the thread\n");
printf("this is a thread");
sleep(10);
pthread_join(t1,NULL);
}