// program to undersatnd json parsing(in python)


//correct json
let JSON_string='{"name":"Yogesh"}'

//incorrect json
let JSON1_string='{name:Yogesh}'

//converting into json abject
let obj=JSON.parse(JSON1_string);

//printing the type of the object
console.log("Type of obj:"+ typeof(obj))

