package com.trg.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Insert {

	public static void main(String[] args) {

		try {
			DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
			Connection conn = 	DriverManager.getConnection (
					"jdbc:oracle:thin:@localhost:1521:xe", "oracle", "oracle");
			
			Statement stmt = conn.createStatement();
			int count = stmt
					.executeUpdate("insert into book values(4071,'MBA','Soham',1111)");
			if (count > 0)
				System.out.println("Record is inserted successfully !!");

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

	}

}
