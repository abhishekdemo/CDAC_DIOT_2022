select * from user_tables;
select * from user_tab_columns;

create table student
(

student_rollno number,
student_city varchar2(100),
student_register_expire date,
student_date_expire date,
student_membership_status varchar(100)
);

describe student;
 
drop table student;

create table student
(

student_rollno number,
student_city varchar2(100),
student_register_expire date,
student_date_expire date,


student_membership_status varchar(100)
);

alter table student 
add(student_Address varchar(100),student_Contact number)

describe student;

alter table student
modify(student_contact varchar(3999))

alter table student
rename column student_address to student_member_adress 

alter table student
drop column student_contact

rename student to student_practice
describe student_practice

comment on table student_practice is 'student_rollno';
select * from user_tab_comments;


