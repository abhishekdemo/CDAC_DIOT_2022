SELECT * FROM USER_TABLES; 
SELECT * FROM USER_TAB_columns;
create table MY_FIRST_TABLE
(
my_number_column number,
my_float_column number(5,2),
my_date_column date,
my_timestamp_column timestamp,
my_timestampTZ_column timestamp with time zone,
my_varchar2_column varchar2(100)
);

describe my_first_table;
	

DROP TABLE MY_FIRST_TABLE;
create table MY_FIRST_TABLE
(
my_number_column number,
my_float_column number(5,2),
my_date_column date,
my_timestamp_column timestamp,
my_timestampTZ_column timestamp with time zone,
my_varchar2_column varchar2(100)
);


RENAME MY_FIRST_TABLE TO MY_FIRST_TABLE_NEW;
describe MY_FIRST_TABLE_NEW;
comment on table my_first_table_new is 'My first table comment';
select * from user_tab_comments;


alter table my_first_table_new 
add(my_first_custom_column date,my_second_custom_column number)

alter table my_first_table_new
drop(my_first_custom_column,my_second_custom_column)
