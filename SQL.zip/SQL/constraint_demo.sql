create table lms_members
(   MEMBER_ID number, 
    MEMBER_NAME varchar2(100),	
    CITY varchar2(100),	
    date_of_birth date,
    DATE_REGISTER date, 
    --constraint cons3 not null, 
    DATE_EXPIRE	date, 
    MEMBERSHIP_STATUS varchar2(100)
    -- constraint cons1 primary key(member_id),
    -- CONSTRAINT cons2 CHECK(DATE_OF_BIRTH > to_date('01-01-2022','dd-mm-yyyy') ),
    -- constraint con3 unique(member_name)

    );
drop table lms_members
desc lms_members
select * from lms_members

insert into lms_members values(1,'yogesh','pune',to_date('03-08-2022','dd-mm-yyyy'),to_date('15-09-2022','dd-mm-yyyy'),to_date('15-03-2023','dd-mm-yyyy'),'student')
insert into lms_members values(2,'yogesh2','pune2',to_date('03-08-2022','dd-mm-yyyy'),to_date('15-09-2022','dd-mm-yyyy'),to_date('15-03-2023','dd-mm-yyyy'),'student')
insert into lms_members values(2,'yogesh3','pune3',to_date('03-08-2022','dd-mm-yyyy'),to_date('15-09-2022','dd-mm-yyyy'),to_date('15-03-2023','dd-mm-yyyy'),'student')

ALTER TABLE lms_members drop constraint cons1;
ALTER TABLE lms_members drop constraint cons2;
ALTER TABLE lms_members drop constraint cons3;
ALTER TABLE lms_members drop constraint cons4;

