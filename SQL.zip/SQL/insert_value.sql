select * from user_tables;
select * from user_tab_colums;


create  table lms_member
(
lms_member_member_id number,
lms_member_member_name varchar(20),
lms_memeber_member_city varchar(20),
lms_member_member_date date

);

describe lms_member

alter table lms_member
add(add_memebe number);

alter table lms_member
add(add_mem varchar(20));

insert into lms_member(lms_member_member_id,lms_member_member_name )values('101','Abhishek')
select * from lms_member;
insert into lms_member(lms_member_member_id,lms_member_member_name )values('102','mohsin')

