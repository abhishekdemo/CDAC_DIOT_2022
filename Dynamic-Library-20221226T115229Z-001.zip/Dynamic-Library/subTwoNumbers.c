int subTwoNumbers(int num1, int num2)
{
    int res = num1 - num2;
    return res;
}