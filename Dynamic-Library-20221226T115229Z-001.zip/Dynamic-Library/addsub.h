int addTwoNumbers(int, int);
int subTwoNumbers(int, int);
